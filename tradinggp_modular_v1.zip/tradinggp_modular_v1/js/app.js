// ── AUTH TAB TOGGLE ──────────────────────────────────────────
function showAuthTab(tab) {
  var isLogin = tab === "login";
  $("auth-login").style.display = isLogin ? "block" : "none";
  $("auth-register").style.display = isLogin ? "none" : "block";
  $("tab-login").style.background = isLogin ? "var(--bl)" : "transparent";
  $("tab-login").style.color = isLogin ? "#fff" : "var(--tx3)";
  $("tab-register").style.background = isLogin ? "transparent" : "var(--bl)";
  $("tab-register").style.color = isLogin ? "var(--tx3)" : "#fff";
  $("auth-err").style.display = "none";
  $("auth-err2").style.display = "none";
}

function showAuthErr(id, msg) {
  var el = $(id); el.textContent = msg; el.style.display = "block";
}

function doAuthLogin() {
  if (!fbAuth) { showAuthErr("auth-err","Firebase indisponível"); return; }
  var email=$("auth-email").value.trim(), pass=$("auth-pass").value;
  if (!email||!pass) { showAuthErr("auth-err","Preencha email e senha"); return; }
  var btn=$("auth-btn-login"); btn.disabled=true; btn.textContent="ENTRANDO...";
  $("auth-err").style.display="none";
  fbAuth.signInWithEmailAndPassword(email,pass)
    .catch(function(e){
      var msg=e.code==="auth/user-not-found"?"Usuário não encontrado":
              e.code==="auth/wrong-password"?"Senha incorreta":
              e.code==="auth/invalid-email"?"Email inválido":e.message;
      showAuthErr("auth-err",msg);
    }).finally(function(){ btn.disabled=false; btn.textContent="ENTRAR"; });
}

function doAuthRegister() {
  if (!fbAuth) { showAuthErr("auth-err2","Firebase indisponível"); return; }
  var name=$("auth-name").value.trim(), email=$("auth-email2").value.trim(), pass=$("auth-pass2").value;
  if (!name||name.length<2) { showAuthErr("auth-err2","Digite seu nome"); return; }
  if (!email) { showAuthErr("auth-err2","Digite seu email"); return; }
  if (!pass||pass.length<6) { showAuthErr("auth-err2","Senha mínima: 6 caracteres"); return; }
  var btn=$("auth-btn-register"); btn.disabled=true; btn.textContent="CRIANDO...";
  $("auth-err2").style.display="none";
  fbAuth.createUserWithEmailAndPassword(email,pass)
    .then(function(cred){ return cred.user.updateProfile({displayName:name}); })
    .catch(function(e){
      var msg=e.code==="auth/email-already-in-use"?"Email já cadastrado":
              e.code==="auth/invalid-email"?"Email inválido":e.message;
      showAuthErr("auth-err2",msg); throw e;
    }).finally(function(){ btn.disabled=false; btn.textContent="CRIAR CONTA"; });
}

function doForgotPassword() {
  if (!fbAuth) return;
  var email = $("auth-email").value.trim();
  if (!email) { showAuthErr("auth-err","Digite o email para recuperar a senha"); return; }
  fbAuth.sendPasswordResetEmail(email)
    .then(function() { showAuthErr("auth-err","Email de recuperação enviado!"); $("auth-err").style.color="var(--g)"; })
    .catch(function(e) { showAuthErr("auth-err", e.message); });
}

function doAuthLogout() {
  if (!fbAuth) return;
  if (groupUnsubscribe) { groupUnsubscribe(); groupUnsubscribe=null; }
  if (typeof clearSoloGroupSubscriptions==="function") clearSoloGroupSubscriptions();
  currentUser=null; currentRoomId=""; currentRoomData=null;
  fbAuth.signOut().then(function() { showAuthScreen(); }).catch(function(err){ console.error("Erro ao sair:",err); });
}

function getUserDisplayName() {
  if (currentUser && currentUser.displayName) return currentUser.displayName;
  return "Jogador";
}

function hideLegacyProfileUI() {
  if ($("ps")) $("ps").style.display = "none";
}

function updateContextActionsUI() {
  var inGroup = isInGroupContext();
  var isCreator = inGroup && currentRoomData && currentRoomData.createdBy === getIdentityUid();
  if ($("solo-back-wrap")) $("solo-back-wrap").style.display = inGroup ? "block" : "none";
  if ($("invite-btn")) $("invite-btn").style.display = inGroup ? "block" : "none";
  if ($("group-leave-wrap")) $("group-leave-wrap").style.display = (inGroup && !isCreator) ? "block" : "none";
  if ($("group-delete-wrap")) $("group-delete-wrap").style.display = (inGroup && isCreator) ? "block" : "none";
  if ($("s-rst")) $("s-rst").style.display = inGroup ? "none" : "block";
  if ($("danger-zone-title")) $("danger-zone-title").style.display = inGroup ? "none" : "block";
}

function leaveGroupById(roomId) {
  var uid=getIdentityUid();
  if(!uid||!roomId||!fbDb)return Promise.resolve();
  var group=(myGroupsCache||[]).find(function(g){return g.roomId===roomId;});
  var roomName=group?group.roomName:roomId;
  return Promise.all([
    fbDb.ref("rooms/"+roomId+"/members/"+uid).remove(),
    fbDb.ref("groupPortfolios/"+roomId+"/"+uid).remove(),
    fbDb.ref("groupHistory/"+roomId+"/"+uid).remove(),
    fbDb.ref("userRooms/"+uid+"/"+roomId).remove()
  ]).then(function(){
    var profs=getProfiles().filter(function(p){var m=getProfileMeta(p);return!(m&&m.type==="group"&&m.roomId===roomId);});
    localStorage.setItem("hb_profiles_v1",JSON.stringify(profs));
    Object.keys(localStorage).forEach(function(k){
      if(k.indexOf("hb_state_v3_grupo_"+roomId+"_")===0)localStorage.removeItem(k);
      if(k.indexOf("hb_goal_v1_grupo_"+roomId+"_")===0)localStorage.removeItem(k);
    });
    if(currentUser&&currentRoomId===roomId)localStorage.removeItem("hb_active_room_"+currentUser.uid);
    myGroupsCache=(myGroupsCache||[]).filter(function(g){return g.roomId!==roomId;});
    if(currentRoomId===roomId){notif("Você saiu do grupo "+roomName);return switchToSoloProfile();}
    notif("Você saiu do grupo "+roomName); renderGroupPanel();
  });
}

function deleteGroupById(roomId) {
  var uid=getIdentityUid();
  if(!uid||!roomId||!fbDb)return Promise.resolve();
  var group=(myGroupsCache||[]).find(function(g){return g.roomId===roomId;});
  var roomName=group?group.roomName:roomId;
  var createdBy=group?group.createdBy:"";
  if(createdBy&&createdBy!==uid){notif("Apenas o criador pode excluir o grupo","err");return Promise.resolve();}
  return fbDb.ref("rooms/"+roomId).once("value").then(function(snap){
    var room=snap.val()||{};
    var members=room.members||{};
    var updates={};
    Object.keys(members).forEach(function(memberUid){
      updates["userRooms/"+memberUid+"/"+roomId]=null;
      updates["groupPortfolios/"+roomId+"/"+memberUid]=null;
      updates["groupHistory/"+roomId+"/"+memberUid]=null;
    });
    updates["rooms/"+roomId]=null;
    return fbDb.ref().update(updates);
  }).then(function(){
    var profs=getProfiles().filter(function(p){var m=getProfileMeta(p);return!(m&&m.type==="group"&&m.roomId===roomId);});
    localStorage.setItem("hb_profiles_v1",JSON.stringify(profs));
    Object.keys(localStorage).forEach(function(k){
      if(k.indexOf("hb_state_v3_grupo_"+roomId+"_")===0)localStorage.removeItem(k);
      if(k.indexOf("hb_goal_v1_grupo_"+roomId+"_")===0)localStorage.removeItem(k);
    });
    if(currentUser&&currentRoomId===roomId)localStorage.removeItem("hb_active_room_"+currentUser.uid);
    myGroupsCache=(myGroupsCache||[]).filter(function(g){return g.roomId!==roomId;});
    if(currentRoomId===roomId){notif("Grupo "+roomName+" excluído");return switchToSoloProfile();}
    notif("Grupo "+roomName+" excluído"); renderGroupPanel();
  });
}

function leaveCurrentGroup() {
  if(!currentRoomId)return Promise.resolve();
  return leaveGroupById(currentRoomId);
}

function deleteCurrentGroup() {
  if(!currentRoomId)return Promise.resolve();
  return deleteGroupById(currentRoomId);
}


function switchToSoloProfile() {
  var soloId=ensureSoloProfile(); if(!soloId)return;
  currentRoomId=""; currentRoomData=null;
  localStorage.removeItem("hb_room_id");
  // keep hb_active_room_ so group can be resumed later
  if(groupUnsubscribe){groupUnsubscribe();groupUnsubscribe=null;}
  clearSoloGroupSubscriptions();
  localStorage.setItem(LS_PROFILE, soloId);
  setActiveScreen("ma");
  loadSoloFromFirebase().then(function(){
    return loadSoloHistoryFromFirebase().catch(function(){equityHistory=loadEquityHistory();});
  }).then(function(){
    goal=loadGoal(); updateAuthIdentityUI(); render(); updateContextActionsUI();
    // load groups without blocking solo return
    return loadMyGroupsFromFirebase().then(function(){
      renderGroupPanel();
    }).catch(function(err){
      console.error("Erro ao carregar meus grupos no solo:",err);
      renderGroupPanel();
    });
  }).catch(function(err){
    console.error("Erro ao voltar para solo:",err);
    // fallback: enter solo anyway
    try{
      goal=loadGoal(); updateAuthIdentityUI(); render(); renderGroupPanel(); updateContextActionsUI();
      notif("Voltou ao solo (fallback local)","err");
    }catch(e2){
      console.error("Fallback do solo falhou:",e2);
      notif("Erro ao voltar ao solo","err");
    }
  });
}

function updateAuthIdentityUI() {
  var name = getIdentityName();
  var el = $("profile-indicator");
  if (!el) return;
  if (currentRoomId) {
    var roomName = (currentRoomData && currentRoomData.name) ||
      (function(){
        var found=(myGroupsCache||[]).find(function(g){return g.roomId===currentRoomId;});
        return found?found.roomName:currentRoomId;
      })();
    el.innerHTML='<span style="color:var(--a)">🏆 '+roomName+'</span> <span style="color:var(--tx4);font-size:9px">· '+name+'</span>';
    return;
  }
  el.textContent = "Perfil: " + name;
}

function getUserUid() {
  return currentUser ? currentUser.uid : null;
}
function getIdentityUid() { return currentUser ? currentUser.uid : null; }
function getIdentityName() { return (currentUser && currentUser.displayName) ? currentUser.displayName : "Jogador"; }

function isInGroupContext() { return !!currentRoomId; }
function isInSoloContext() { return !currentRoomId; }
function getCurrentContextKey() {
  var uid=getIdentityUid()||"anon";
  return currentRoomId?("group:"+currentRoomId+":"+uid):("solo:"+uid);
}
function getCurrentContextType() { return currentRoomId?"group":"solo"; }

function getSoloProfileId() {
  var uid = getIdentityUid();
  return uid ? ("solo_" + uid) : "";
}

function ensureSoloProfile() {
  var uid = getIdentityUid();
  if (!uid) return "";
  var soloId = getSoloProfileId();
  var displayName = getIdentityName();
  setProfileMeta(soloId, {profileId:soloId, displayName:displayName, type:"solo", uid:uid});
  var profs = getProfiles();
  if (profs.indexOf(soloId) === -1) {
    profs.unshift(soloId);
    localStorage.setItem("hb_profiles_v1", JSON.stringify(profs));
  }
  if (!localStorage.getItem("hb_state_v3_" + soloId)) {
    localStorage.setItem("hb_state_v3_" + soloId, JSON.stringify({bal:100000,port:{},trd:[],pending:[],divs:{},totalDiv:0,checkedDivDate:"",initialBal:100000,firstTradeDate:""}));
  }
  if (!localStorage.getItem(LS_PROFILE)) {
    localStorage.setItem(LS_PROFILE, soloId);
  }
  return soloId;
}

// ── SOLO FIREBASE HELPERS ────────────────────────────────────────────────────
function getSoloPortfolioRef() {
  var uid=getIdentityUid();
  if(!uid||!fbDb)return null;
  return fbDb.ref("soloPortfolios/"+uid);
}

function buildSoloPayloadFromMemory() {
  return {cash:bal||0,positions:port||{},trades:trd||[],pendingOrders:pending||[],
    dividends:divs||{},totalDiv:totalDiv||0,initialBal:initialBal||100000,
    firstTradeDate:firstTradeDate||"",updatedAt:Date.now()};
}

function applySoloPayloadToMemory(data) {
  data=data||{};
  bal=Number(data.cash||0);
  port=data.positions||{};
  trd=data.trades||[];
  pending=data.pendingOrders||[];
  divs=data.dividends||{};
  totalDiv=Number(data.totalDiv||0);
  initialBal=Number(data.initialBal||100000);
  firstTradeDate=data.firstTradeDate||"";
}

function syncSoloToLocalCache() {
  var soloId=getSoloProfileId();if(!soloId)return;
  localStorage.setItem("hb_state_v3_"+soloId,JSON.stringify({
    bal:bal||0,port:port||{},trd:trd||[],pending:pending||[],
    divs:divs||{},totalDiv:totalDiv||0,checkedDivDate:checkedDivDate||"",
    initialBal:initialBal||100000,firstTradeDate:firstTradeDate||""
  }));
}

function loadSoloFromFirebase() {
  var ref=getSoloPortfolioRef();
  if(!ref)return Promise.reject(new Error("Solo/Firebase indisponível"));
  return ref.once("value").then(function(snap){
    var data=snap.val();
    if(!data){
      data={cash:100000,positions:{},trades:[],pendingOrders:[],dividends:{},totalDiv:0,initialBal:100000,firstTradeDate:"",updatedAt:Date.now()};
      return ref.set(data).then(function(){return data;});
    }
    return data;
  }).then(function(data){
    applySoloPayloadToMemory(data);
    syncSoloToLocalCache();
    return data;
  });
}

function saveSoloToFirebase() {
  var ref=getSoloPortfolioRef();if(!ref)return Promise.resolve();
  syncSoloToLocalCache();
  return ref.update(buildSoloPayloadFromMemory());
}

// ── SOLO HISTORY FIREBASE HELPERS ────────────────────────────────────────────
function getSoloHistoryRef() {
  var uid=getIdentityUid();
  if(!uid||!fbDb)return null;
  return fbDb.ref("soloHistory/"+uid+"/points");
}

function normalizeEquityHistory(points) {
  if (!Array.isArray(points)) return [];
  return points.map(function(p) {
    if (!p) return null;
    var ts =
      (typeof p.t !== "undefined" && !isNaN(Number(p.t))) ? Number(p.t) :
      (typeof p.ts !== "undefined" && !isNaN(Number(p.ts))) ? Number(p.ts) :
      (typeof p.time !== "undefined" && !isNaN(Number(p.time))) ? Number(p.time) :
      (p.date && !isNaN(new Date(p.date).getTime())) ? new Date(p.date).getTime() :
      (p.dt && !isNaN(new Date(p.dt).getTime())) ? new Date(p.dt).getTime() : NaN;
    var val =
      typeof p.v !== "undefined" ? Number(p.v) :
      typeof p.value !== "undefined" ? Number(p.value) :
      typeof p.total !== "undefined" ? Number(p.total) : NaN;
    if (isNaN(ts) || isNaN(val)) return null;
    return {t:ts, v:val};
  }).filter(function(p){return !!p;})
    .sort(function(a,b){return a.t-b.t;});
}

function loadSoloHistoryFromFirebase() {
  var ref = getSoloHistoryRef();
  if (!ref) return Promise.resolve([]);

  return ref.once("value").then(function(snap) {
    var data = snap.val();
    var points = Array.isArray(data) ? data : [];
    points = normalizeEquityHistory(points);

    equityHistory = points;

    localStorage.setItem(getProfileKey("hb_eqhist_v1"), JSON.stringify(points));
    localStorage.setItem(getProfileKey(LS_EQUITY), JSON.stringify(points));

    return points;
  });
}

function saveSoloHistoryToFirebase() {
  var ref=getSoloHistoryRef();if(!ref)return Promise.resolve();
  var points=normalizeEquityHistory(equityHistory||[]);
  localStorage.setItem(getProfileKey("hb_eqhist_v1"),JSON.stringify(points));
  return ref.set(points);
}

// ── GROUP PORTFOLIO/HISTORY FIREBASE HELPERS ─────────────────────────────────
function getUserRoomsRef() {
  var uid=getIdentityUid();
  if(!uid||!fbDb)return null;
  return fbDb.ref("userRooms/"+uid);
}

function getGroupPortfolioRef(roomId) {
  var uid=getIdentityUid();
  if(!uid||!fbDb||!roomId)return null;
  return fbDb.ref("groupPortfolios/"+roomId+"/"+uid);
}
function getGroupHistoryRef(roomId) {
  var uid=getIdentityUid();
  if(!uid||!fbDb||!roomId)return null;
  return fbDb.ref("groupHistory/"+roomId+"/"+uid+"/points");
}
function buildGroupPayloadFromMemory() {
  return {cash:bal||0,positions:port||{},trades:trd||[],pendingOrders:pending||[],
    dividends:divs||{},totalDiv:totalDiv||0,initialBal:initialBal||100000,
    firstTradeDate:firstTradeDate||"",updatedAt:Date.now()};
}
function applyGroupPayloadToMemory(data) {
  data=data||{};
  bal=Number(data.cash||0); port=data.positions||{}; trd=data.trades||[];
  pending=data.pendingOrders||[]; divs=data.dividends||{};
  totalDiv=Number(data.totalDiv||0); initialBal=Number(data.initialBal||100000);
  firstTradeDate=data.firstTradeDate||"";
}
function syncGroupToLocalCache(profileId) {
  if(!profileId)return;
  localStorage.setItem("hb_state_v3_"+profileId,JSON.stringify({
    bal:bal||0,port:port||{},trd:trd||[],pending:pending||[],
    divs:divs||{},totalDiv:totalDiv||0,checkedDivDate:checkedDivDate||"",
    initialBal:initialBal||100000,firstTradeDate:firstTradeDate||""
  }));
}
function loadGroupPortfolioFromFirebase(roomId, profileId) {
  var ref=getGroupPortfolioRef(roomId);
  if(!ref)return Promise.reject(new Error("Group portfolio indisponível"));
  return ref.once("value").then(function(snap){
    var data=snap.val();
    if(!data){
      var initBal=(currentRoomData&&currentRoomData.initialBal)||100000;
      data={cash:initBal,positions:{},trades:[],pendingOrders:[],dividends:{},
        totalDiv:0,initialBal:initBal,firstTradeDate:"",updatedAt:Date.now()};
      return ref.set(data).then(function(){return data;});
    }
    return data;
  }).then(function(data){
    applyGroupPayloadToMemory(data);
    syncGroupToLocalCache(profileId);
    return data;
  });
}
function saveGroupPortfolioToFirebase(roomId, profileId) {
  var ref=getGroupPortfolioRef(roomId);if(!ref)return Promise.resolve();
  syncGroupToLocalCache(profileId);
  return ref.update(buildGroupPayloadFromMemory());
}
function loadGroupHistoryFromFirebase(roomId, profileId) {
  var ref=getGroupHistoryRef(roomId);
  if(!ref)return Promise.resolve([]);
  return ref.once("value").then(function(snap){
    var data=snap.val();
    var points=normalizeEquityHistory(Array.isArray(data)?data:[]);
    equityHistory=points;
    localStorage.setItem(getProfileKey("hb_eqhist_v1"),JSON.stringify(points));
    return points;
  });
}
function saveGroupHistoryToFirebase(roomId) {
  var ref=getGroupHistoryRef(roomId);if(!ref)return Promise.resolve();
  var points=normalizeEquityHistory(equityHistory||[]);
  localStorage.setItem(getProfileKey("hb_eqhist_v1"),JSON.stringify(points));
  return ref.set(points);
}
function isCurrentProfileGroup() {
  return isInGroupContext();
}
function saveCurrentContextToFirebase() {
  if (isInGroupContext()) {
    return Promise.all([
      saveGroupPortfolioToFirebase(currentRoomId, getCurrentProfile()),
      saveGroupHistoryToFirebase(currentRoomId)
    ]);
  }
  if (isInSoloContext()) {
    return Promise.all([saveSoloToFirebase(), saveSoloHistoryToFirebase()]);
  }
  return Promise.resolve();
}


function pushEquityPoint() {
  var total = bal + portValue();
  var now = Date.now();

  equityHistory = Array.isArray(equityHistory) ? equityHistory : [];

  var d = new Date(now);
  var dayKey =
    d.getFullYear() + "-" +
    String(d.getMonth() + 1).padStart(2, "0") + "-" +
    String(d.getDate()).padStart(2, "0");

  var replaced = false;

  for (var i = equityHistory.length - 1; i >= 0; i--) {
    var p = equityHistory[i];
    if (!p || typeof p.t === "undefined") continue;

    var pd = new Date(Number(p.t));
    var pKey =
      pd.getFullYear() + "-" +
      String(pd.getMonth() + 1).padStart(2, "0") + "-" +
      String(pd.getDate()).padStart(2, "0");

    if (pKey === dayKey) {
      equityHistory[i] = { t: now, v: total };
      replaced = true;
      break;
    }

    if (Number(p.t) < now) break;
  }

  if (!replaced) {
    equityHistory.push({ t: now, v: total });
  }

  equityHistory.sort(function(a, b) {
    return Number(a.t) - Number(b.t);
  });

  var cacheKey = isInGroupContext()
    ? "hb_eqhist_v1_grp_" + currentRoomId + "_" + (currentUser && currentUser.uid || "anon")
    : getProfileKey("hb_eqhist_v1");

  localStorage.setItem(cacheKey, JSON.stringify(equityHistory));
  saveCurrentContextToFirebase();
}




// ── FIREBASE INIT ────────────────────────────────────────────
var fbDb=null, fbAuth=null, currentUser=null;
try {
  if(typeof firebase!=="undefined"){
    if(!firebase.apps.length) firebase.initializeApp({apiKey:"AIzaSyCx1J0mvZz9G29fwc0d9wQdkJM-9DjfnLY",databaseURL:"https://trading-gp-default-rtdb.firebaseio.com",projectId:"trading-gp",authDomain:"trading-gp.firebaseapp.com"});
    fbDb=firebase.database();
    fbAuth=firebase.auth();
  }
} catch(e){console.log("FB err:",e.message);}

// ── FIREBASE INIT ────────────────────────────────────────────
// ── FIREBASE INIT ────────────────────────────────────────────
var roomSwitchToken=0,roomLoadToken=0;
var myGroupsCache=[];
var soloGroupUnsubs={};

var currentRoomId="",currentRoomData=null,groupUnsubscribe=null;
function genRoomId(){return Math.random().toString(36).substr(2,6).toUpperCase();}
function createRoom(n,b,d,t){if(!fbDb)return Promise.reject(new Error("Firebase indisponível"));var id=genRoomId();return fbDb.ref("rooms/"+id).set({id:id,name:n,initialBal:b,endDate:d,targetPct:t,createdBy:getIdentityUid(),createdAt:Date.now(),members:{}}).then(function(){localStorage.setItem("hb_room_id",id);currentRoomId=id;return id;});}
function joinRoom(id){if(!fbDb)return Promise.reject(new Error("Firebase indisponível"));return fbDb.ref("rooms/"+id).once("value").then(function(s){if(!s.exists())throw new Error("Sala não encontrada");localStorage.setItem("hb_room_id",id);currentRoomId=id;currentRoomData=s.val();return s.val();});}
function pushMyStats(){
  var uid=getIdentityUid();
  if(!currentRoomId||!uid||!fbDb)return;
  var total=bal+portValue(),initB=(currentRoomData&&currentRoomData.initialBal)||initialBal;
  var name=getIdentityName();
  fbDb.ref("rooms/"+currentRoomId+"/members/"+uid).set({
    uid:uid, name:name, total:total,
    pct:(total-initB)/initB*100,
    updatedAt:Date.now(),
    history:(equityHistory||[]).slice(-30).map(function(p){return{t:p.t,v:p.v};})
  });
}
var _lp=0;function maybePushStats(){if(!currentRoomId||!getIdentityUid())return;var n=Date.now();if(n-_lp>60000){_lp=n;pushMyStats();}}
// ── MY GROUPS FROM FIREBASE ──────────────────────────────────────────────────
function loadMyGroupsFromFirebase() {
  var uid=getIdentityUid();
  var ref=getUserRoomsRef();
  if(!uid||!ref)return Promise.resolve([]);
  return ref.once("value").then(function(snap){
    var data=snap.val()||{};
    var list=Object.keys(data).map(function(roomId){
      var x=data[roomId]||{};
      return{roomId:roomId,roomName:x.roomName||roomId,
        initialBal:Number(x.initialBal||100000),endDate:x.endDate||"",
        targetPct:Number(x.targetPct||0),
        memberName:x.memberName||getIdentityName(),
        createdAt:Number(x.createdAt||0),
        createdBy:x.createdBy||""};
    });
    list.sort(function(a,b){return(b.createdAt||0)-(a.createdAt||0);});
    myGroupsCache=list;
    return list;
  });
}

function loadGroupSummaryFromFirebase(roomId) {
  var uid=getIdentityUid();
  if(!uid||!fbDb||!roomId)return Promise.resolve(null);
  return Promise.all([
    fbDb.ref("groupPortfolios/"+roomId+"/"+uid).once("value"),
    fbDb.ref("rooms/"+roomId+"/members").once("value")
  ]).then(function(results){
    var portData=results[0].val()||null;
    var members=results[1].val()||{};
    if(!portData)return null;
    var cash=Number(portData.cash||0);
    var positions=portData.positions||{};
    var totalPositions=0;
    Object.keys(positions).forEach(function(k){
      var p=positions[k]||{};
      totalPositions+=Number(p.qty||0)*Number(p.avgPrice||0);
    });
    var total=cash+totalPositions;
    var initialBal=Number(portData.initialBal||100000);
    var pct=initialBal>0?((total-initialBal)/initialBal*100):0;
    var ranking=Object.values(members).sort(function(a,b){return Number(b.pct||0)-Number(a.pct||0);});
    var myName=getIdentityName();
    var myPos=ranking.findIndex(function(x){return(x.uid&&x.uid===uid)||(x.name===myName);});
    return{total:total,pct:pct,pos:myPos>=0?myPos+1:null,totalMembers:ranking.length};
  });
}


function clearSoloGroupSubscriptions() {
  Object.keys(soloGroupUnsubs).forEach(function(roomId){
    try{soloGroupUnsubs[roomId]();}catch(e){}
  });
  soloGroupUnsubs={};
}

function subscribeGroup(cb){if(!currentRoomId||!fbDb)return;if(groupUnsubscribe)groupUnsubscribe();var ref=fbDb.ref("rooms/"+currentRoomId+"/members");ref.on("value",function(s){cb(s.val()||{});});groupUnsubscribe=function(){ref.off();};}
function getRoomInviteLink(){return window.location.origin+window.location.pathname+"?room="+encodeURIComponent(currentRoomId);}
function showCreateRoom() {
  var n=prompt("🏆 Nome do grupo:");
  if(!n||!n.trim())return;
  n=n.trim();
  var bStr=prompt("💰 Saldo inicial para todos (R$):","100000");
  if(!bStr)return;
  var b=parseFloat(bStr.replace(",","."));
  if(isNaN(b)||b<=0){notif("Saldo inválido","err");return;}
  var d=prompt("📅 Data de encerramento (DD/MM/AAAA):");
  if(!d)return;
  var tStr=prompt("🎯 Meta de rentabilidade (%) — opcional:","5");
  var t=parseFloat(tStr)||0;

  createRoom(n,b,d,t).then(function(roomId){
    currentRoomId=roomId;
    currentRoomData={id:roomId,name:n,initialBal:b,endDate:d,targetPct:t,createdBy:getIdentityUid()};
    if(currentUser)localStorage.setItem("hb_active_room_"+currentUser.uid,roomId);
    var pid="grupo_"+roomId+"_"+getIdentityName();
    setProfileMeta(pid,{profileId:pid,displayName:getIdentityName(),type:"group",roomId:roomId,roomName:n});
    localStorage.setItem("hb_profile_v1",pid);
    return fbDb.ref("rooms/"+roomId+"/members/"+getIdentityUid()).set({
      uid:getIdentityUid(),name:getIdentityName(),joinedAt:Date.now()
    }).then(function(){
      return fbDb.ref("userRooms/"+getIdentityUid()+"/"+roomId).set({
        roomName:n,initialBal:b,endDate:d,targetPct:t,
        memberName:getIdentityName(),createdAt:Date.now(),createdBy:getIdentityUid()
      });
    }).then(function(){
      return loadGroupPortfolioFromFirebase(roomId,pid);
    }).then(function(){
      return loadGroupHistoryFromFirebase(roomId,pid);
    }).then(function(){
      setActiveScreen("ma");
      updateAuthIdentityUI(); render(); renderGroupPanel(); updateContextActionsUI();
      notif("Grupo criado com sucesso!");
      // atualiza lista sem bloquear
      return loadMyGroupsFromFirebase().catch(function(err){
        console.error("Erro ao atualizar Meus Grupos:",err);
      });
    });
  }).catch(function(err){
    console.error("Erro real ao criar grupo:",err);
    notif("Erro ao criar grupo: "+(err&&err.message?err.message:"desconhecido"),"err");
  });
}
function showJoinRoom(){var c=prompt("Código do grupo:");if(!c)return;joinRoom(c.toUpperCase().trim()).then(function(r){notif("Entrou: "+r.name);renderGroupRoom();subscribeGroup(renderGroupRanking);pushMyStats();}).catch(function(){notif("Grupo não encontrado","err");});}

function joinGroupAsGuest() {
  var uid=getIdentityUid();
  var errEl=$("gs-err");
  if(!uid){errEl.textContent="Faça login antes de entrar no grupo";errEl.style.display="block";return;}
  errEl.style.display="none";
  if(!currentRoomData){notif("Erro: sala não encontrada","err");return;}
  var name=getIdentityName();
  fbDb.ref("rooms/"+currentRoomId+"/members/"+uid).set({uid:uid,name:name,joinedAt:Date.now()})
  .then(function(){
    localStorage.setItem("hb_active_room_"+uid, currentRoomId);
    fbDb.ref("userRooms/"+uid+"/"+currentRoomId).set({
      roomName:currentRoomData.name||currentRoomId,
      initialBal:Number(currentRoomData.initialBal||100000),
      endDate:currentRoomData.endDate||"",
      targetPct:Number(currentRoomData.targetPct||0),
      memberName:name,
      createdAt:Number(currentRoomData.createdAt||Date.now()),
      createdBy:currentRoomData.createdBy||""
    }).catch(function(e){console.error("userRooms write failed:",e);});
    var profileId="grupo_"+currentRoomId+"_"+name;
    setProfileMeta(profileId,{profileId:profileId,displayName:name,type:"group",roomId:currentRoomId,roomName:currentRoomData.name||currentRoomId});
    var profs=getProfiles();
    if(profs.indexOf(profileId)===-1){profs.push(profileId);localStorage.setItem("hb_profiles_v1",JSON.stringify(profs));}
    localStorage.setItem("hb_profile_v1",profileId);
    return loadGroupPortfolioFromFirebase(currentRoomId,profileId);
  }).then(function(){
    return loadGroupHistoryFromFirebase(currentRoomId,getCurrentProfile());
  }).then(function(){
    $("gs").style.display="none";
    clearInviteFromUrl();
    pushMyStats();
    notif("Bem-vindo ao grupo "+currentRoomData.name+"!");
    initApp();
  }).catch(function(err){
    console.error(err);
    notif("Erro ao entrar no grupo","err");
  });
}


function showGroupJoinScreen(roomData){
  $("ts").style.display="none";$("ps").style.display="none";$("ma").style.display="none";
  $("gs").style.display="flex";$("gs").style.flexDirection="column";
  $("gs-name").textContent=roomData.name||currentRoomId;
  var rules="";
  if(roomData.initialBal)rules+="💰 Saldo inicial: <b>R$ "+Number(roomData.initialBal).toLocaleString("pt-BR")+"</b><br>";
  if(roomData.endDate)rules+="📅 Prazo: <b>"+roomData.endDate+"</b><br>";
  if(roomData.targetPct)rules+="🎯 Meta: <b>+"+roomData.targetPct+"%</b><br>";
  if(roomData.createdBy)rules+="👑 Criado por: <b>"+roomData.createdBy+"</b><br>";
  $("gs-rules").innerHTML=rules||"Grupo de trading — boa sorte!";
}
function shareRoomInvite(){
  var r=currentRoomData||{};
  var msg =
    "🚀 *TRADING GP - DESAFIO COMEÇOU* 🚀\n\n"+
    "Você foi convidado para um campeonato de trading.\n\n"+
    "💰 Capital inicial: R$ "+Number(r.initialBal||100000).toLocaleString("pt-BR",{minimumFractionDigits:2})+"\n"+
    "📅 Prazo: "+(r.endDate||"")+"\n"+
    "🎯 Meta: "+(r.targetPct||0)+"%\n\n"+
    "📊 Simulador realista\n"+
    "🏆 Ranking ao vivo\n"+
    "🔥 Competição entre jogadores\n\n"+
    "👉 Entre agora e mostre quem é o melhor trader:\n"+
    getRoomInviteLink();
  window.open("https://wa.me/?text="+encodeURIComponent(msg),"_blank");
}
function switchToProfile(profileId) {
  localStorage.setItem("hb_profile_v1", profileId);
  var meta = getProfileMeta(profileId);
  if (!meta && profileId && profileId.indexOf("grupo_") === 0) {
    var _sp = profileId.split("_");
    meta = {profileId:profileId, displayName:_sp.slice(2).join("_"), type:"group", roomId:_sp[1], roomName:_sp[1]};
    setProfileMeta(profileId, meta);
  }
  if (meta && meta.type === "group" && meta.roomId) {
    currentRoomId = meta.roomId;
    currentRoomData = null;
    if (currentUser) localStorage.setItem("hb_active_room_"+currentUser.uid, meta.roomId);
    if (groupUnsubscribe) { groupUnsubscribe(); groupUnsubscribe=null; }
    var thisSwitch = ++roomSwitchToken;
    joinRoom(meta.roomId).then(function(room) {
      if (thisSwitch !== roomSwitchToken) return;
      currentRoomData = room; meta.roomName = room.name; setProfileMeta(profileId, meta);
      return loadGroupPortfolioFromFirebase(meta.roomId, profileId);
    }).then(function() {
      if (thisSwitch !== roomSwitchToken) return;
      return loadGroupHistoryFromFirebase(meta.roomId, profileId);
    }).then(function() {
      if (thisSwitch !== roomSwitchToken) return;
      goal = {
        endDate: (currentRoomData && currentRoomData.endDate) || "",
        target: Number((currentRoomData && currentRoomData.targetPct) || 0)
      };
      setActiveScreen("ma");
      updateAuthIdentityUI(); render(); renderGroupPanel(); updateContextActionsUI();
      notif("Perfil: " + meta.displayName);
    }).catch(function(err) {
      console.error("Erro ao carregar grupo:", err);
      notif("Erro ao carregar carteira do grupo","err");
    });
    return;
  }
  if (groupUnsubscribe) { groupUnsubscribe(); groupUnsubscribe=null; }
  currentRoomId = ""; currentRoomData = null;
  if (currentUser) localStorage.removeItem("hb_active_room_"+currentUser.uid);
  return loadSoloFromFirebase().then(function() {
    return loadSoloHistoryFromFirebase().catch(function() {
      equityHistory = loadEquityHistory();
    });
  }).then(function() {
    goal = loadGoal();
    setActiveScreen("ma");
    updateAuthIdentityUI();
    render();
    renderGroupPanel();
    updateContextActionsUI();
    notif("Perfil: " + (meta ? meta.displayName : profileId));
  });
}


function renderGroupPanel() {
  clearSoloGroupSubscriptions();
  var soloView=$("group-solo-view"), roomView=$("group-room-view"), noRoom=$("group-noroom");
  if(!soloView||!roomView||!noRoom)return;

  if(isInGroupContext()&&currentRoomData){
    soloView.style.display="none"; roomView.style.display="block"; noRoom.style.display="none";
    if($("group-room-name"))$("group-room-name").textContent=currentRoomData.name||currentRoomId;
    var mArr=[];
    if(currentRoomData.endDate)mArr.push("📅 "+currentRoomData.endDate);
    if(currentRoomData.targetPct)mArr.push("🎯 Meta +"+currentRoomData.targetPct+"%");
    if(currentRoomData.initialBal)mArr.push("💰 R$ "+Number(currentRoomData.initialBal).toLocaleString("pt-BR"));
    if($("group-room-meta"))$("group-room-meta").textContent=mArr.join(" · ");
    if(currentRoomId)subscribeGroup(renderGroupRanking);
    updateContextActionsUI();
    return;
  }

  roomView.style.display="none";
  updateContextActionsUI();

  loadMyGroupsFromFirebase().then(function(groups){
    if(groups&&groups.length){
      soloView.style.display="block"; noRoom.style.display="none";
      renderSoloGroupList(groups);
    } else {
      soloView.style.display="none"; noRoom.style.display="block";
    }
  }).catch(function(err){
    console.error("Erro ao carregar meus grupos:",err);
    soloView.style.display="none"; noRoom.style.display="block";
  });
}


function getMyGroupProfiles() {
  return myGroupsCache || [];
}

function renderSoloGroupList(groups) {
  var el=$("group-solo-list");if(!el)return;
  el.innerHTML="";
  if(!groups||!groups.length){
    el.innerHTML='<div class="empty">Você ainda não participa de nenhum grupo.</div>';
    return;
  }
  groups.forEach(function(group){
    var isCreator=group.createdBy===getIdentityUid();
    var card=document.createElement("div");
    card.style.cssText="background:var(--bg2);border:1px solid var(--bd);border-radius:12px;padding:14px;margin-bottom:10px;";
    card.innerHTML=
      '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">'+
        '<div>'+
          '<div style="font-size:12px;font-weight:700;color:var(--a)">'+group.roomName+'</div>'+
          '<div style="font-size:9px;color:var(--tx4);margin-top:2px">'+group.roomId+'</div>'+
        '</div>'+
        '<div class="grp-pct" style="font-size:14px;font-weight:700;color:var(--tx3)">...</div>'+
      '</div>'+
      '<div class="grp-meta" style="font-size:10px;color:var(--tx2);margin-bottom:10px">Carregando...</div>'+
      '<div style="display:flex;gap:6px">'+
        '<button class="grp-open-btn" style="flex:1;padding:8px 10px;background:linear-gradient(135deg,#1e4a80,#2563eb);border:none;border-radius:6px;color:#fff;font-size:10px;font-weight:700;cursor:pointer;font-family:inherit">OPERAR</button>'+
        '<button class="grp-admin-btn" style="padding:8px 10px;background:transparent;border:1px solid '+(isCreator?'var(--r)':'#f59e0b')+';"+'+"border-radius:6px;color:"+(isCreator?'var(--r)':'#f59e0b')+';font-size:10px;font-weight:700;cursor:pointer;font-family:inherit">'+(isCreator?'EXCLUIR':'SAIR')+'</button>'+
      '</div>';
    (function(g,c,creator){
      c.querySelector(".grp-open-btn").onclick=function(){
        currentRoomId=g.roomId;
        currentRoomData={id:g.roomId,name:g.roomName,initialBal:g.initialBal,endDate:g.endDate,targetPct:g.targetPct,createdBy:g.createdBy||""};
        if(currentUser)localStorage.setItem("hb_active_room_"+currentUser.uid,g.roomId);
        var pid="grupo_"+g.roomId+"_"+(g.memberName||getIdentityName());
        setProfileMeta(pid,{profileId:pid,displayName:g.memberName||getIdentityName(),type:"group",roomId:g.roomId,roomName:g.roomName});
        switchToProfile(pid);
      };
      c.querySelector(".grp-admin-btn").onclick=function(){
        if(creator){
          if(!confirm("Deseja EXCLUIR o grupo "+g.roomName+" para todos?"))return;
          deleteGroupById(g.roomId).catch(function(err){console.error(err);notif("Erro ao excluir grupo","err");});
        } else {
          if(!confirm("Deseja sair do grupo "+g.roomName+"?"))return;
          leaveGroupById(g.roomId).catch(function(err){console.error(err);notif("Erro ao sair do grupo","err");});
        }
      };
      loadGroupSummaryFromFirebase(g.roomId).then(function(s){
        if(!s)return;
        var pctEl=c.querySelector(".grp-pct"),metaEl=c.querySelector(".grp-meta");
        var color=s.pct>=0?"var(--g)":"var(--r)";
        var medal=s.pos===1?"🥇":s.pos===2?"🥈":s.pos===3?"🥉":(s.pos?"#"+s.pos:"—");
        if(pctEl){pctEl.style.color=color;pctEl.textContent=(s.pct>=0?"+":"")+s.pct.toFixed(2)+"%";}
        if(metaEl){metaEl.textContent="R$ "+Number(s.total).toLocaleString("pt-BR",{minimumFractionDigits:2})+" · "+medal+" de "+s.totalMembers;}
      }).catch(function(){});
    })(group,card,isCreator);
    el.appendChild(card);
  });
}


function renderGroupRoom(){if(!currentRoomId||!currentRoomData){document.getElementById("group-noroom").style.display="block";document.getElementById("group-room").style.display="none";return;}document.getElementById("group-noroom").style.display="none";document.getElementById("group-room").style.display="block";document.getElementById("group-room-name").textContent=currentRoomData.name||currentRoomId;}
function renderGroupRanking(members){
  drawGroupChart(members);
  var list=Object.values(members).sort(function(a,b){return(b.pct||0)-(a.pct||0);});
  var el=$("group-ranking"); if(!el)return; el.innerHTML="";
  var currentName=getIdentityName();
  var myIndex=-1;
  list.forEach(function(m,i){
    if(m.name===currentName) myIndex=i;
    var isMe=m.name===currentName;
    var medal=i===0?"🥇":i===1?"🥈":i===2?"🥉":"#"+(i+1);
    var color=(m.pct||0)>=0?"var(--g)":"var(--r)";
    var div=document.createElement("div");
    div.style.cssText="display:flex;align-items:center;padding:10px 12px;margin-bottom:6px;background:"+(isMe?"rgba(96,165,250,.12)":"var(--bg3)")+";border-radius:8px;border:1px solid "+(isMe?"rgba(96,165,250,.3)":"var(--bd2)")+";gap:10px";
    div.innerHTML="<div style='font-size:16px;min-width:24px'>"+medal+"</div>"+
      "<div style='flex:1'><div style='font-size:12px;font-weight:700'>"+(m.name||"Jogador")+(isMe?" <span style='font-size:9px;color:var(--bl)'>(você)</span>":"")+"</div>"+
      "<div style='font-size:9px;color:var(--tx4)'>R$ "+Number(m.total||0).toLocaleString("pt-BR",{minimumFractionDigits:2})+"</div></div>"+
      "<div style='font-size:14px;font-weight:700;color:"+color+"'>"+(m.pct>=0?"+":"")+Number(m.pct||0).toFixed(2)+"%</div>";
    el.appendChild(div);
  });
  var medalEl=$("group-my-medal"),pctEl=$("group-my-pct");
  if(medalEl&&pctEl){
    if(myIndex>=0){
      medalEl.textContent=myIndex===0?"🥇":myIndex===1?"🥈":myIndex===2?"🥉":"#"+(myIndex+1);
      var me=list[myIndex];
      pctEl.textContent=((me.pct||0)>=0?"+":"")+Number(me.pct||0).toFixed(2)+"%";
      pctEl.style.color=(me.pct||0)>=0?"var(--g)":"var(--r)";
    } else { medalEl.textContent="—";pctEl.textContent="—";pctEl.style.color="var(--tx2)"; }
  }
}

function drawGroupChart(members){var canvas=document.getElementById("group-chart");if(!canvas)return;var ctx2=canvas.getContext("2d");canvas.width=canvas.offsetWidth||320;var W=canvas.width,H=160;ctx2.clearRect(0,0,W,H);var list=Object.values(members),colors=["#00d8a0","#60a5fa","#fbbf24","#ff4466","#a78bfa"],allPts=[];list.forEach(function(m){if(m.history)allPts=allPts.concat(m.history.map(function(p){return p.v;}));});if(!allPts.length)return;var minV=Math.min.apply(null,allPts)*0.999,maxV=Math.max.apply(null,allPts)*1.001,pad=8;list.forEach(function(m,ci){if(!m.history||m.history.length<2)return;ctx2.strokeStyle=colors[ci%colors.length];ctx2.lineWidth=2;ctx2.beginPath();m.history.forEach(function(p,i){var x=pad+(i/(m.history.length-1))*(W-pad*2),y=H-pad-(p.v-minV)/(maxV-minV)*(H-pad*2);if(i===0)ctx2.moveTo(x,y);else ctx2.lineTo(x,y);});ctx2.stroke();});}
(function(){var params=new URLSearchParams(window.location.search),room=params.get("room");if(room&&!currentRoomId){joinRoom(room.toUpperCase()).catch(function(){});}else if(currentRoomId){joinRoom(currentRoomId).then(function(){renderGroupRoom();subscribeGroup(renderGroupRanking);}).catch(function(){});}})();

//  Ativos:
//  Ativos: 19 mais lquidos do Ibovespa + IBOV como referncia 
var TICKERS = ["PETR4","VALE3","ITUB4","BBDC4","BBAS3","ABEV3","WEGE3","RENT3","PRIO3","BERK34","B3SA3","EMBJ3","RADL3","SUZB3","VIVT3","EQTL3","DOLA11","RDOR3","UGPA3"];

// Full universe available for tape customization
var ALL_TAPE_TICKERS = [
  // Ibovespa mais negociados
  "PETR4","PETR3","VALE3","ITUB4","BBDC4","BBAS3","ABEV3","WEGE3","RENT3","PRIO3",
  "B3SA3","EMBJ3","RADL3","SUZB3","VIVT3","EQTL3","RDOR3","UGPA3","ELET3","ELET6",
  "HAPV3","TOTS3","CPLE6","ENEV3","CSAN3","LREN3","MGLU3","NTCO3","BEEF3","BRFS3",
  "CYRE3","EVEN3","FLRY3","GGBR4","GOAU4","HYPE3","IRBR3","JBSS3","KLBN11","MRVE3",
  "MULT3","POMO4","QUAL3","RAIL3","SBSP3","TAEE11","TIMS3","TRPL4","USIM5","YDUQ3",
  // ETFs populares
  "BOVA11","SMAL11","IVVB11","DOLA11","BBSD11","GOLD11","HASH11","PIBB11","SPXI11","EURP11",
  // BDRs mais negociados
  "BERK34","AAPL34","AMZO34","GOGL34","MSFT34","NVDC34","TSLA34","META34","NFLX34","GOOGL34"
];
var ALL_TAPE_NAMES = {
  PETR4:"Petrobras PN",PETR3:"Petrobras ON",VALE3:"Vale ON",ITUB4:"Itau PN",BBDC4:"Bradesco PN",
  BBAS3:"Banco Brasil ON",ABEV3:"Ambev ON",WEGE3:"WEG ON",RENT3:"Localiza ON",PRIO3:"PetroReconcavo ON",
  B3SA3:"B3 ON",EMBJ3:"Embraer ON",RADL3:"Raia Drogasil ON",SUZB3:"Suzano ON",VIVT3:"Vivo ON",
  EQTL3:"Equatorial ON",RDOR3:"Rede DOr ON",UGPA3:"Ultrapar ON",ELET3:"Eletrobras ON",ELET6:"Eletrobras PNB",
  HAPV3:"Hapvida ON",TOTS3:"Totvs ON",CPLE6:"Copel PNB",ENEV3:"Eneva ON",CSAN3:"Cosan ON",
  LREN3:"Lojas Renner ON",MGLU3:"Magazine Luiza ON",NTCO3:"Grupo Boticario ON",BEEF3:"Minerva ON",BRFS3:"BRF ON",
  CYRE3:"Cyrela ON",EVEN3:"Even ON",FLRY3:"Fleury ON",GGBR4:"Gerdau PN",GOAU4:"Metalurgica Gerdau PN",
  HYPE3:"Hypera ON",IRBR3:"IRB Brasil ON",JBSS3:"JBS ON",KLBN11:"Klabin UNT",MRVE3:"MRV ON",
  MULT3:"Multiplan ON",POMO4:"Marcopolo PN",QUAL3:"Qualicorp ON",RAIL3:"Rumo ON",SBSP3:"Sabesp ON",
  TAEE11:"Taesa UNT",TIMS3:"TIM ON",TRPL4:"CTEEP PN",USIM5:"Usiminas PNA",YDUQ3:"Yduqs ON",
  BOVA11:"ETF Ibovespa",SMAL11:"ETF Small Caps",IVVB11:"ETF S&P500",DOLA11:"ETF Dolar",
  BBSD11:"ETF BB Dividendos",GOLD11:"ETF Ouro",HASH11:"ETF Cripto",PIBB11:"ETF IBrX50",
  SPXI11:"ETF S&P500 BRL",EURP11:"ETF Europa",
  BERK34:"Berkshire BDR",AAPL34:"Apple BDR",AMZO34:"Amazon BDR",GOGL34:"Google BDR",
  MSFT34:"Microsoft BDR",NVDC34:"Nvidia BDR",TSLA34:"Tesla BDR",META34:"Meta BDR",
  NFLX34:"Netflix BDR",GOOGL34:"Alphabet BDR"
};

// Load tape tickers from localStorage or use defaults
var PINNED_TICKERS = ["IBOV","USDBRL"];
function loadTapeTickers() {
  try {
    var saved = JSON.parse(localStorage.getItem("hb_tape_v1") || "null");
    if (Array.isArray(saved) && saved.length > 0) {
      // Always ensure IBOV and USDBRL are first, remove duplicates
      var filtered = saved.filter(function(t){ return PINNED_TICKERS.indexOf(t) === -1; });
      return PINNED_TICKERS.concat(filtered);
    }
  } catch(e) {}
  return ["IBOV","USDBRL","PETR4","VALE3","ITUB4","BBDC4","BBAS3","ABEV3","WEGE3","RENT3","PRIO3","BERK34","B3SA3","EMBJ3","RADL3","SUZB3","VIVT3","EQTL3","DOLA11","RDOR3"];
}
var TAPE_TICKERS = loadTapeTickers();
var DISPLAY_TICKERS = ["IBOV"].concat(TICKERS);
var NAMES = {
  "USDBRL":"Dolar Comercial (USD/BRL)",
  "IBOV":"Ibovespa Index",
  IBOV:"Ibovespa Index", PETR4:"Petrobras PN", VALE3:"Vale ON", ITUB4:"Itau Unibanco PN",
  BBDC4:"Bradesco PN", BBAS3:"Banco do Brasil ON", ABEV3:"Ambev ON", WEGE3:"WEG ON",
  RENT3:"Localiza ON", PRIO3:"PetroReconcavo ON", BERK34:"Berkshire BDR", B3SA3:"B3 ON",
  EMBJ3:"Embraer ON", RADL3:"Raia Drogasil ON", SUZB3:"Suzano ON", VIVT3:"Telefonica Vivo ON",
  EQTL3:"Equatorial ON", DOLA11:"Dolar ETF", RDOR3:"Rede DOr ON", UGPA3:"Ultrapar ON"
};
var TVSYM = {
  "USDBRL":"USDBRL",
  "IBOV":"BMFBOVESPA:IBOV",
  IBOV:"BMFBOVESPA:IBOV", PETR4:"BMFBOVESPA:PETR4", VALE3:"BMFBOVESPA:VALE3",
  ITUB4:"BMFBOVESPA:ITUB4", BBDC4:"BMFBOVESPA:BBDC4", BBAS3:"BMFBOVESPA:BBAS3",
  ABEV3:"BMFBOVESPA:ABEV3", WEGE3:"BMFBOVESPA:WEGE3", RENT3:"BMFBOVESPA:RENT3",
  PRIO3:"BMFBOVESPA:PRIO3", BERK34:"BMFBOVESPA:BERK34", B3SA3:"BMFBOVESPA:B3SA3",
  EMBJ3:"BMFBOVESPA:EMBJ3", RADL3:"BMFBOVESPA:RADL3", SUZB3:"BMFBOVESPA:SUZB3",
  VIVT3:"BMFBOVESPA:VIVT3", EQTL3:"BMFBOVESPA:EQTL3", DOLA11:"BMFBOVESPA:DOLA11",
  RDOR3:"BMFBOVESPA:RDOR3", UGPA3:"BMFBOVESPA:UGPA3"
};
// Brapi endpoint  busca em lotes de 10 (limite PRO por req)
var TICKERS_A = TICKERS.slice(0, 10); // batch 1
var TICKERS_B = TICKERS.slice(10);    // batch 2

var BRAPI   = "https://brapi.dev/api";
var REFRESH = 60; // 1 minuto

var LS_TOKEN  = "hb_token_v6";
var LS_FONT   = "hb_font_v1";
var FONT_SCALES = [0.82, 0.88, 0.94, 1.0, 1.08, 1.16, 1.25];
var fontIdx = 3; // default = 1.0

function applyFontScale(idx) {
  fontIdx = Math.max(0, Math.min(FONT_SCALES.length-1, idx));
  var scale = FONT_SCALES[fontIdx];
  // Apply to html element so all rem units scale proportionally
  document.documentElement.style.fontSize = (scale * 16) + "px";
  localStorage.setItem(LS_FONT, fontIdx);
  var pct = Math.round(scale * 100);
  var lbl = document.getElementById("fs-label");
  if (lbl) lbl.textContent = pct + "%";
  var up = document.getElementById("fs-up");
  var dn = document.getElementById("fs-down");
  if (up) up.style.opacity = fontIdx >= FONT_SCALES.length-1 ? "0.3" : "1";
  if (dn) dn.style.opacity = fontIdx <= 0 ? "0.3" : "1";
}

// Load saved font scale
(function(){
  var saved = parseInt(localStorage.getItem(LS_FONT));
  if (!isNaN(saved)) fontIdx = saved;
  // Apply after DOM ready
  setTimeout(function(){ applyFontScale(fontIdx); }, 0);
})();
var LS_INVITE = "hb_invite_v1"; // invite code set by owner

// Simple obfuscation - not encryption, just avoids plain token in URL
function encodeToken(t) {
  return btoa(t.split("").reverse().join("")).replace(/=/g,"");
}
function decodeToken(s) {
  var pad = s.length % 4 === 0 ? s : s + "====".slice(s.length % 4);
  try { return atob(pad).split("").reverse().join(""); } catch(e) { return ""; }
}

// Check URL for encoded token (invite link)
function getTokenFromUrl() {
  var params = new URLSearchParams(window.location.search);
  var enc = params.get("t");
  if (enc) return decodeToken(enc);
  return "";
}

function isOwner() {
  return localStorage.getItem("hb_is_owner") === "1";
}
var LS_THEME  = "hb_theme_v1";
var LS_PROFILE = "hb_profile_v1";   // active profile name
var LS_PROFILES = "hb_profiles_v1"; // list of profiles

function getProfileKey(key) {
  var id = (currentUser && currentUser.uid) ? currentUser.uid : (localStorage.getItem(LS_PROFILE) || "default");
  return key + "_" + id;
}

// ── PROFILE METADATA ─────────────────────────────────────────
function getProfileMeta(profileId) {
  try { return JSON.parse(localStorage.getItem("hb_meta_"+profileId)||"null"); }
  catch(e) { return null; }
}
function setProfileMeta(profileId, meta) {
  localStorage.setItem("hb_meta_"+profileId, JSON.stringify(meta));
}
function isGroupProfile(profileId) {
  var m = getProfileMeta(profileId); return m && m.type === "group";
}
function getProfileDisplayName(profileId) {
  var m = getProfileMeta(profileId); return m ? m.displayName : profileId;
}
function deleteProfile(name) {
  var profiles = getProfiles().filter(function(p){ return p !== name; });
  localStorage.setItem("hb_profiles_v1", JSON.stringify(profiles));
  // Clean all keys for this profile
  var prefix = "_"+name;
  Object.keys(localStorage).forEach(function(k){ if(k.endsWith(prefix)) localStorage.removeItem(k); });
  localStorage.removeItem("hb_meta_"+name);
  if (localStorage.getItem(LS_PROFILE) === name) localStorage.removeItem(LS_PROFILE);
}

function loadStateForProfile() {
  try {
    var s = JSON.parse(localStorage.getItem(getProfileKey("hb_state_v3")) || "{}");
    return {
      bal:            s.bal      !== undefined ? s.bal : 100000,
      port:           s.port     || {},
      trd:            s.trd      || [],
      pending:        s.pending  || [],
      divs:           s.divs     || [],
      totalDiv:       s.totalDiv || 0,
      checkedDivDate: s.checkedDivDate || "",
      initialBal:     s.initialBal || 100000,
      firstTradeDate: s.firstTradeDate || ""
    };
  } catch(e) { return {bal:100000,port:{},trd:[],pending:[],divs:[],totalDiv:0,checkedDivDate:"",initialBal:100000,firstTradeDate:""}; }
}

function saveStateForProfile() {
  localStorage.setItem(getProfileKey("hb_state_v3"), JSON.stringify({
    bal:bal, port:port, trd:trd, pending:pending,
    divs:divs, totalDiv:totalDiv, checkedDivDate:checkedDivDate,
    initialBal:initialBal, firstTradeDate:firstTradeDate
  }));
}

function getProfiles() {
  try { return JSON.parse(localStorage.getItem(LS_PROFILES) || "[]"); }
  catch(e) { return []; }
}

function saveProfile(name) {
  var profiles = getProfiles();
  if (profiles.indexOf(name) === -1) profiles.push(name);
  localStorage.setItem(LS_PROFILES, JSON.stringify(profiles));
  localStorage.setItem(LS_PROFILE, name);
}

function deleteProfile(name) {
  // Remove all keys for this profile
  var keys = ["hb_state_v3","hb_goal_v1","hb_equity_v1","hb_news_v1","hb_tape_v1"];
  keys.forEach(function(k){ localStorage.removeItem(k+"_"+name); });
  var profiles = getProfiles().filter(function(p){ return p !== name; });
  localStorage.setItem(LS_PROFILES, JSON.stringify(profiles));
  // If deleted active profile, clear it
  if (localStorage.getItem(LS_PROFILE) === name) localStorage.removeItem(LS_PROFILE);
}

function getCurrentProfile() {
  return localStorage.getItem(LS_PROFILE) || "";
}

function applyTheme(t) {
  document.documentElement.classList.remove("light","matrix");
  document.body.classList.remove("light","matrix");
  if (t === "light") {
    document.documentElement.classList.add("light");
    document.body.classList.add("light");
  }
  if (t === "matrix") {
    document.documentElement.classList.add("matrix");
    document.body.classList.add("matrix");
  }
  localStorage.setItem(LS_THEME, t);
  var db=document.getElementById("theme-dark"), lb=document.getElementById("theme-light"), mb=document.getElementById("theme-matrix");
  if (db) db.style.outline = t==="dark"?"2px solid #60a5fa":"none";
  if (lb) lb.style.outline = t==="light"?"2px solid #1a70c8":"none";
  if (mb) mb.style.outline = t==="matrix"?"2px solid #00ff66":"none";
}
var LS_NEWS   = "hb_news_v1";
var LS_STATE  = "hb_state_v3";
var LS_GOAL   = "hb_goal_v1";
var LS_EQUITY = "hb_equity_v1"; // historico patrimonio

//  State 
var token = "7fzZFBceKppCEPxfSrXswz"; // token centralizado Brapi

function loadState() { return loadStateForProfile(); }
function saveState() {
  saveStateForProfile();
  saveCurrentContextToFirebase();
}
function saveGoal() { localStorage.setItem(getProfileKey("hb_goal_v1"), JSON.stringify(goal)); }

function loadGoal() {
  try { return JSON.parse(localStorage.getItem(getProfileKey("hb_goal_v1"))||"{}"); }
  catch(e) { return {}; }
}
function loadEquityHistory() {
  try { return JSON.parse(localStorage.getItem(getProfileKey(LS_EQUITY))||"[]"); } catch(e) { return []; }
}
function saveEquityHistory() {
  equityHistory = Array.isArray(equityHistory) ? equityHistory : [];

  if (isInGroupContext()) {
    var grpKey = "hb_eq_grp_" + currentRoomId + "_" + (currentUser && currentUser.uid || "anon");
    localStorage.setItem(grpKey, JSON.stringify(equityHistory));
    saveGroupHistoryToFirebase(currentRoomId);
  } else {
    localStorage.setItem(getProfileKey(LS_EQUITY), JSON.stringify(equityHistory));
    localStorage.setItem(getProfileKey("hb_eqhist_v1"), JSON.stringify(equityHistory));
    saveSoloHistoryToFirebase();
  }
}

var st = loadState();
var bal = st.bal, port = st.port, trd = st.trd, pending = st.pending;
var divs = st.divs, totalDiv = st.totalDiv, checkedDivDate = st.checkedDivDate;
var initialBal = st.initialBal || 100000;  // saldo inicial do simulador
var firstTradeDate = st.firstTradeDate || ""; // data da primeira compra
var goal = loadGoal();
var equityHistory = loadEquityHistory();

var prices = {}, chg = {}, pct = {};
var sel = "IBOV", per = "D", side = "buy", qty = 0;
var orderMode = "market";
var cd = REFRESH, cdi, rfi, nft;
var tvWidget = null, tvScriptLoaded = false;

var $ = function(id) { return document.getElementById(id); };

applyTheme(localStorage.getItem(LS_THEME) || "dark");

// ── SOUND ENGINE ──────────────────────────────────────────────────────────────
var SFX_ENABLED = localStorage.getItem("hb_sfx") !== "0";
function sfxCtx(){return new(window.AudioContext||window.webkitAudioContext)();}
function sfxN(c,d){var b=c.createBuffer(1,c.sampleRate*d,c.sampleRate),a=b.getChannelData(0);for(var i=0;i<a.length;i++)a[i]=Math.random()*2-1;var s=c.createBufferSource();s.buffer=b;return s;}
function sfxO(c,f,t){var o=c.createOscillator();o.type=t||"sine";o.frequency.value=f;return o;}
function sfxG(c,v){var g=c.createGain();g.gain.value=v;return g;}
function sfxLP(c,f){var x=c.createBiquadFilter();x.type="lowpass";x.frequency.value=f;return x;}
function sfxHP(c,f){var x=c.createBiquadFilter();x.type="highpass";x.frequency.value=f;return x;}

function sfxBolt(){
  if(!SFX_ENABLED)return;
  var c=sfxCtx(),t=c.currentTime;
  (function(st){var n=sfxN(c,.07),h=sfxHP(c,1500),l=sfxLP(c,4000),g=sfxG(c,0);g.gain.setValueAtTime(0,st);g.gain.linearRampToValueAtTime(2.5,st+.003);g.gain.exponentialRampToValueAtTime(.001,st+.065);n.connect(h);h.connect(l);l.connect(g);g.connect(c.destination);n.start(st);var o=sfxO(c,180,"triangle"),g2=sfxG(c,.8);g2.gain.setValueAtTime(.8,st);g2.gain.exponentialRampToValueAtTime(.001,st+.04);o.connect(g2);g2.connect(c.destination);o.start(st);o.stop(st+.05);})(t);
  setTimeout(function(){var c2=sfxCtx(),t2=c2.currentTime;var o=sfxO(c2,2800),g=sfxG(c2,.15);o.frequency.exponentialRampToValueAtTime(1200,t2+.08);g.gain.setValueAtTime(.15,t2);g.gain.exponentialRampToValueAtTime(.001,t2+.12);o.connect(g);g.connect(c2.destination);o.start(t2);o.stop(t2+.15);},90);
  setTimeout(function(){var c3=sfxCtx(),t3=c3.currentTime;var n=sfxN(c3,.09),h=sfxHP(c3,800),l=sfxLP(c3,3500),g=sfxG(c3,0);g.gain.setValueAtTime(0,t3);g.gain.linearRampToValueAtTime(3,t3+.004);g.gain.exponentialRampToValueAtTime(.001,t3+.08);n.connect(h);h.connect(l);l.connect(g);g.connect(c3.destination);n.start(t3);var o=sfxO(c3,140,"triangle"),g2=sfxG(c3,1);g2.gain.setValueAtTime(1,t3);g2.gain.exponentialRampToValueAtTime(.001,t3+.06);o.connect(g2);g2.connect(c3.destination);o.start(t3);o.stop(t3+.07);},200);
}

function sfxShot(){
  if(!SFX_ENABLED)return;
  var c=sfxCtx(),t=c.currentTime;
  (function(){var n=sfxN(c,.6),l=sfxLP(c,3000);l.frequency.exponentialRampToValueAtTime(400,t+.4);var g=sfxG(c,0);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(4.5,t+.002);g.gain.exponentialRampToValueAtTime(.8,t+.05);g.gain.exponentialRampToValueAtTime(.001,t+.5);n.connect(l);l.connect(g);g.connect(c.destination);n.start(t);})();
  (function(){var o=sfxO(c,55),g=sfxG(c,0);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(1.8,t+.008);g.gain.exponentialRampToValueAtTime(.001,t+.25);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.3);var o2=sfxO(c,80),g2=sfxG(c,0);g2.gain.setValueAtTime(0,t);g2.gain.linearRampToValueAtTime(1.2,t+.005);g2.gain.exponentialRampToValueAtTime(.001,t+.2);o2.connect(g2);g2.connect(c.destination);o2.start(t);o2.stop(t+.25);})();
  setTimeout(function(){var c2=sfxCtx(),t2=c2.currentTime;var n=sfxN(c2,.08),h=sfxHP(c2,3000),g=sfxG(c2,0);g.gain.setValueAtTime(0,t2);g.gain.linearRampToValueAtTime(1.5,t2+.002);g.gain.exponentialRampToValueAtTime(.001,t2+.07);n.connect(h);h.connect(g);g.connect(c2.destination);n.start(t2);},60);
  setTimeout(function(){var c3=sfxCtx(),t3=c3.currentTime;var n=sfxN(c3,.4),l=sfxLP(c3,600),g=sfxG(c3,0);g.gain.setValueAtTime(0,t3);g.gain.linearRampToValueAtTime(.4,t3+.01);g.gain.exponentialRampToValueAtTime(.001,t3+.35);n.connect(l);l.connect(g);g.connect(c3.destination);n.start(t3);},350);
}

function sfxBoltShot(){sfxBolt();setTimeout(sfxShot,420);}

function sfxHitPlate(){
  if(!SFX_ENABLED)return;
  sfxShot();
  setTimeout(function(){var c=sfxCtx(),t=c.currentTime;var n=sfxN(c,.05),l=sfxLP(c,2500),g=sfxG(c,0);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(3.5,t+.002);g.gain.exponentialRampToValueAtTime(.001,t+.04);n.connect(l);l.connect(g);g.connect(c.destination);n.start(t);
  [[420,1],[680,.8],[1100,.6],[1750,.4],[2800,.25],[3600,.15]].forEach(function(p){var o=sfxO(c,p[0]),g2=sfxG(c,0),dec=.6+(p[0]>1000?.3:0);g2.gain.setValueAtTime(0,t);g2.gain.linearRampToValueAtTime(p[1]*.5,t+.003);g2.gain.exponentialRampToValueAtTime(.001,t+dec);o.connect(g2);g2.connect(c.destination);o.start(t);o.stop(t+dec+.1);});},220);
}

function sfxHitDirt(){
  if(!SFX_ENABLED)return;
  sfxShot();
  setTimeout(function(){var c=sfxCtx(),t=c.currentTime;var n=sfxN(c,.25),l=sfxLP(c,250),g=sfxG(c,0);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(2.8,t+.003);g.gain.exponentialRampToValueAtTime(.3,t+.03);g.gain.exponentialRampToValueAtTime(.001,t+.2);n.connect(l);l.connect(g);g.connect(c.destination);n.start(t);var o=sfxO(c,60),g2=sfxG(c,0);g2.gain.setValueAtTime(0,t);g2.gain.linearRampToValueAtTime(1.5,t+.005);g2.gain.exponentialRampToValueAtTime(.001,t+.15);o.connect(g2);g2.connect(c.destination);o.start(t);o.stop(t+.2);},300);
}

function sfxDividend(){
  if(!SFX_ENABLED)return;
  var c=sfxCtx();
  var cum=0;
  for(var i=0;i<16;i++){(function(idx,delay){setTimeout(function(){var t=c.currentTime;var n=c.createBuffer(1,c.sampleRate*.05,c.sampleRate),d=n.getChannelData(0);for(var j=0;j<d.length;j++){var e=j<n.length*.1?j/(n.length*.1):Math.exp(-(j-n.length*.1)/(n.length*.15));d[j]=(Math.random()*2-1)*e;}var src=c.createBufferSource();src.buffer=n;var f=c.createBiquadFilter();f.type="bandpass";f.frequency.value=2500+Math.random()*1000;f.Q.value=.8;var g=sfxG(c,.35+Math.random()*.2);src.connect(f);f.connect(g);g.connect(c.destination);src.start(t);var n2=c.createBuffer(1,c.sampleRate*.012,c.sampleRate),d2=n2.getChannelData(0);for(var j=0;j<d2.length;j++)d2[j]=(Math.random()*2-1)*Math.exp(-j/(c.sampleRate*.003));var src2=c.createBufferSource();src2.buffer=n2;var f2=c.createBiquadFilter();f2.type="highpass";f2.frequency.value=5000;var g2=sfxG(c,.5);src2.connect(f2);f2.connect(g2);g2.connect(c.destination);src2.start(t);},delay);})(i,cum);cum+=i<4?130-i*15:75;}
  setTimeout(function(){var t=c.currentTime;[1000,1250].forEach(function(f,i){var o=sfxO(c,f),g=sfxG(c,.2);g.gain.setValueAtTime(.2,t+i*.18);g.gain.exponentialRampToValueAtTime(.001,t+i*.18+.14);o.connect(g);g.connect(c.destination);o.start(t+i*.18);o.stop(t+i*.18+.15);});},1300);
}

var fr = function(n) { return n.toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2}); };
var R  = function(n) { return "R$ "+fr(n); };
var CD = function(s) { return String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0"); };

function notif(msg, t) {
  t = t || "ok";
  var e = $("nf");
  e.textContent = msg;
  e.style.background = t==="err" ? "var(--r)" : "var(--g)";
  e.classList.remove("on"); void e.offsetWidth; e.classList.add("on");
  clearTimeout(nft); nft = setTimeout(function(){ e.classList.remove("on"); }, 3500);
}

var tradeAudioCtx = null;
function ensureTradeAudio(){
  try {
    if (!tradeAudioCtx) tradeAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (tradeAudioCtx.state === "suspended") tradeAudioCtx.resume();
    return tradeAudioCtx;
  } catch(e) { return null; }
}
function beepTone(freq, start, dur, vol, type){
  var ctx = ensureTradeAudio();
  if (!ctx) return;
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
  gain.gain.setValueAtTime(0.0001, ctx.currentTime + start);
  gain.gain.exponentialRampToValueAtTime(vol || 0.03, ctx.currentTime + start + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(ctx.currentTime + start);
  osc.stop(ctx.currentTime + start + dur + 0.02);
}
function playTradeSound(kind){
  try {
    if (kind === "buy") {
      beepTone(740, 0.00, 0.09, 0.035, "triangle");
      beepTone(988, 0.08, 0.11, 0.03, "triangle");
    } else if (kind === "sell") {
      beepTone(660, 0.00, 0.08, 0.035, "square");
      beepTone(440, 0.07, 0.11, 0.03, "square");
    } else if (kind === "pending") {
      beepTone(620, 0.00, 0.05, 0.025, "triangle");
      beepTone(620, 0.08, 0.05, 0.02, "triangle");
    } else if (kind === "limit") {
      beepTone(520, 0.00, 0.05, 0.022, "triangle");
      beepTone(780, 0.06, 0.06, 0.026, "triangle");
      beepTone(1040, 0.13, 0.08, 0.024, "triangle");
    }
  } catch(e) {}
}

//  TradingView 
function loadTV() {
  var uid = "tv"+Date.now();
  $("tvw").innerHTML = '<div id="'+uid+'" style="width:100%;height:100%"></div>';
  function doInit() {
    tvWidget = new TradingView.widget({
      container_id:uid, autosize:true, symbol:TVSYM[sel], interval:per,
      timezone:"America/Sao_Paulo", theme:"dark", style:"1", locale:"br",
      toolbar_bg:"#090d16", allow_symbol_change:false, save_image:false,
      overrides:{
        "paneProperties.background":"#090d16","paneProperties.backgroundType":"solid",
        "paneProperties.vertGridProperties.color":"#0f1e30","paneProperties.horzGridProperties.color":"#0f1e30",
        "scalesProperties.textColor":"#3a5878","scalesProperties.backgroundColor":"#060a12",
        "mainSeriesProperties.candleStyle.upColor":"#00c896","mainSeriesProperties.candleStyle.downColor":"#f04060",
        "mainSeriesProperties.candleStyle.borderUpColor":"#00c896","mainSeriesProperties.candleStyle.borderDownColor":"#f04060",
        "mainSeriesProperties.candleStyle.wickUpColor":"#00c896","mainSeriesProperties.candleStyle.wickDownColor":"#f04060"
      }
    });
  }
  if (window.TradingView) { doInit(); return; }
  if (tvScriptLoaded) { var c=setInterval(function(){ if(window.TradingView){clearInterval(c);doInit();} },100); return; }
  tvScriptLoaded = true;
  var s = document.createElement("script");
  s.src="https://s3.tradingview.com/tv.js"; s.onload=doInit; document.head.appendChild(s);
}

//  Brapi: cotaes em 2 batches + IBOV 
function setSts(s) {
  var e = $("sts");
  if (s==="loading") {
    e.innerHTML='<span class="spin" style="display:inline-block;width:8px;height:8px;border:1.5px solid var(--a);border-top-color:transparent;border-radius:50%;vertical-align:middle;margin-right:4px"></span><span style="color:var(--a)">BUSCANDO</span>';
  } else if (s==="ok") {
    var iv = getRefreshInterval();
    var label = iv===60 ? "REAL 1MIN" : iv===300 ? "REAL 5MIN" : "REAL";
    e.innerHTML='<span class="dot" style="display:inline-block;width:5px;height:5px;border-radius:50%;background:var(--g);vertical-align:middle;margin-right:4px"></span><span style="color:var(--g)">'+label+'</span>';
  } else if (s==="frozen") {
    e.innerHTML='<span style="display:inline-block;width:5px;height:5px;border-radius:50%;background:var(--tx3);vertical-align:middle;margin-right:4px"></span><span style="color:var(--tx3)">CONGELADO</span>';
  } else {
    e.innerHTML='<span style="color:var(--r)">ERRO API</span>';
  }
}

function fetchQ() {
  setSts("loading");

  var urlA      = BRAPI + "/quote/" + TICKERS_A.join(",") + "?fundamental=false&token=" + token;
  var urlB      = BRAPI + "/quote/" + TICKERS_B.join(",") + "?fundamental=false&token=" + token;
  var urlIbov   = BRAPI + "/quote/%5EBVSP?fundamental=false&token=" + token;
  var urlUsdBrl = BRAPI + "/quote/USDBRL=X?fundamental=false&token=" + token;

  function fetchJson(url, label) {
    return fetch(url).then(function(r) {
      if (!r.ok) throw new Error(label + " HTTP " + r.status);
      return r.json();
    }).then(function(data) {
      if (data && data.error) throw new Error(label + ": " + (data.message || "erro Brapi"));
      return data;
    });
  }

  Promise.allSettled([
    fetchJson(urlA, "Lote A"),
    fetchJson(urlB, "Lote B"),
    fetchJson(urlIbov, "IBOV"),
    fetchJson(urlUsdBrl, "USDBRL")
  ]).then(function(results) {
    var okCount = 0;

    function applyBatch(data) {
      if (!data || !data.results) return;
      data.results.forEach(function(q) {
        if (!q || !q.symbol) return;
        if (typeof q.regularMarketPrice !== "undefined") prices[q.symbol] = q.regularMarketPrice;
        if (typeof q.regularMarketChange !== "undefined") chg[q.symbol] = q.regularMarketChange;
        if (typeof q.regularMarketChangePercent !== "undefined") pct[q.symbol] = q.regularMarketChangePercent;
      });
      okCount++;
    }

    if (results[0].status === "fulfilled") applyBatch(results[0].value);
    else console.error("Falha lote A:", results[0].reason);

    if (results[1].status === "fulfilled") applyBatch(results[1].value);
    else console.error("Falha lote B:", results[1].reason);

    if (results[2].status === "fulfilled") {
      var ibov = results[2].value;
      if (ibov && ibov.results && ibov.results.length) {
        var ib = ibov.results[0];
        if (ib.regularMarketPrice) prices["IBOV"] = ib.regularMarketPrice;
        if (ib.regularMarketChange !== undefined) chg["IBOV"] = ib.regularMarketChange;
        if (ib.regularMarketChangePercent !== undefined) pct["IBOV"] = ib.regularMarketChangePercent;
        okCount++;
      }
    } else console.error("Falha IBOV:", results[2].reason);

    if (results[3].status === "fulfilled") {
      var usd = results[3].value;
      if (usd && usd.results && usd.results.length) {
        var us = usd.results[0];
        if (us.regularMarketPrice) prices["USDBRL"] = us.regularMarketPrice;
        if (us.regularMarketChange !== undefined) chg["USDBRL"] = us.regularMarketChange;
        if (us.regularMarketChangePercent !== undefined) pct["USDBRL"] = us.regularMarketChangePercent;
        okCount++;
      }
    } else console.error("Falha USDBRL:", results[3].reason);

    if (okCount > 0) {
      $("hupd").textContent = "Atualizado: " + new Date().toLocaleTimeString("pt-BR");
      cd = REFRESH;
      setSts("ok");

      // Registra ponto no histórico de patrimônio
      var pv = portValue();
      var te = bal + pv;
      var now = new Date();
      equityHistory.push({ t: now.getTime(), v: te });
      saveEquityHistory();

      checkScheduledOrders();
      checkDividends();
      checkPending();
      render();
    } else {
      setSts("err");
      $("hupd").textContent = "Falha na atualização";
    }
  }).catch(function(err) {
    console.error("Erro geral fetchQ:", err);
    setSts("err");
    $("hupd").textContent = "Falha na atualização";
  });
}

function getRefreshInterval() {
  var brt = getBRTDate();
  var dow = brt.getDay();
  if (dow === 0 || dow === 6) return 0; // fim de semana - parado
  var mins = brt.getHours()*60 + brt.getMinutes();
  if (mins >= 600 && mins < 1020) return 60;    // pregao: 1 min
  if (mins >= 1020 && mins < 1140) return 300;  // pos: 5 min
  return 0; // fora de horario - parado
}

function isMarketDataActive() {
  return getRefreshInterval() > 0;
}

function startRefresh() {
  clearInterval(cdi);
  clearInterval(rfi);
  rfi = null;

  var interval = getRefreshInterval();

  function beginActiveRefresh(newInterval) {
    clearInterval(rfi);
    interval = newInterval;
    cd = interval;

    fetchQ();

    rfi = setInterval(function() {
      var iv = getRefreshInterval();

      if (iv === 0) {
        clearInterval(rfi);
        rfi = null;
        setSts("frozen");
        $("hupd").textContent = "Fechamento: " + new Date().toLocaleTimeString("pt-BR");
        return;
      }

      if (iv !== interval) {
        beginActiveRefresh(iv);
        return;
      }

      fetchQ();
    }, interval * 1000);
  }

  if (interval > 0) {
    beginActiveRefresh(interval);
  } else {
    setSts("frozen");
  }

  cdi = setInterval(function() {
    var iv = getRefreshInterval();

    if (iv > 0 && !rfi) {
      beginActiveRefresh(iv);
    }

    if (iv === 0) {
      $("hcd").textContent = "";
    } else {
      cd = cd <= 1 ? iv : cd - 1;
      $("hcd").textContent = "Prox.: " + CD(cd);
    }
  }, 1000);
}

function getBRTDate() {
  // Returns a Date object in BRT (UTC-3)
  var now = new Date();
  var utc = now.getTime() + now.getTimezoneOffset()*60000;
  return new Date(utc - 3*3600000); // BRT = UTC-3
}

function isPregaoOpen() {
  var brt = getBRTDate();
  var dow = brt.getDay(); // 0=Sun,6=Sat
  if (dow === 0 || dow === 6) return false;
  var h = brt.getHours(), m = brt.getMinutes();
  var mins = h*60+m;
  return mins >= 600 && mins < 1020; // 10:00-17:00
}

function nextPregaoOpen() {
  // Returns ms until next 10:00 BRT on a business day
  var brt = getBRTDate();
  var candidate = new Date(brt);
  candidate.setHours(10,0,0,0);
  // If already past 10:00 today, move to next day
  if (brt >= candidate) candidate.setDate(candidate.getDate()+1);
  // Skip weekends
  while (candidate.getDay()===0||candidate.getDay()===6) candidate.setDate(candidate.getDate()+1);
  // Diff in ms
  var nowUTC = new Date().getTime();
  var candUTC = candidate.getTime() + 3*3600000; // back to UTC
  return Math.max(0, candUTC - nowUTC);
}

function nextPregaoDateStr() {
  var brt = getBRTDate();
  var candidate = new Date(brt);
  candidate.setHours(10,0,0,0);
  if (brt >= candidate) candidate.setDate(candidate.getDate()+1);
  while (candidate.getDay()===0||candidate.getDay()===6) candidate.setDate(candidate.getDate()+1);
  return candidate.toLocaleDateString("pt-BR");
}

function updatePregaoBar() {
  var open = isPregaoOpen();
  var sts = $("pregao-sts"), cd2 = $("pregao-cd");
  if (open) {
    sts.className="pregao-open"; sts.textContent="* PREGAO ABERTO";
    // Time to close
    var brt=getBRTDate(), closeMs=(17*60-(brt.getHours()*60+brt.getMinutes()))*60000-brt.getSeconds()*1000;
    var h2=Math.floor(closeMs/3600000), m2=Math.floor((closeMs%3600000)/60000), s2=Math.floor((closeMs%60000)/1000);
    cd2.textContent="Fecha em "+String(h2).padStart(2,"0")+":"+String(m2).padStart(2,"0")+":"+String(s2).padStart(2,"0");
  } else {
    sts.className="pregao-closed";
    var brt2=getBRTDate(), mins2=brt2.getHours()*60+brt2.getMinutes();
    var dow2=brt2.getDay();
    var isPostClose = (dow2>0&&dow2<6) && (mins2>=1020 && mins2<1140);
    sts.textContent = isPostClose ? "* POS-FECHAMENTO" : "* PREGAO FECHADO";
    var ms=nextPregaoOpen();
    var h3=Math.floor(ms/3600000), m3=Math.floor((ms%3600000)/60000), s3=Math.floor((ms%60000)/1000);
    var frozen = !isMarketDataActive();
    cd2.textContent=(frozen?"Dados congelados - ":"")+"Abre em "+String(h3).padStart(2,"0")+":"+String(m3).padStart(2,"0")+":"+String(s3).padStart(2,"0");
  }
}

// Update prego bar every second
setInterval(updatePregaoBar, 1000);

// Check if scheduled orders should fire at prego open
function checkScheduledOrders() {
  if (!isPregaoOpen()) return;
  var toActivate=[], keep=[];
  pending.forEach(function(o) {
    if (o.scheduled) {
      // Convert scheduled order to active limit order
      var activated = JSON.parse(JSON.stringify(o));
      delete activated.scheduled;
      toActivate.push(activated);
    } else keep.push(o);
  });
  if (toActivate.length) {
    pending = keep.concat(toActivate);
    saveState();
    notif(toActivate.length+" ordem(s) agendada(s) ativada(s) no pregao!");
  }
}

// Pending after-hours order (temp storage before user confirms scheduling)
var ahoOrder = null;

function showAHO(orderObj) {
  ahoOrder = orderObj;
  var side = orderObj.side==="buy"?"COMPRA":"VENDA";
  var type = orderObj.lp ? "LIMITADA @ "+R(orderObj.lp) : "A MERCADO";
  $("aho-summary").innerHTML =
    '<span style="color:'+(orderObj.side==="buy"?"var(--g)":"var(--r)")+';font-weight:700">'+side+'</span> - '+
    '<span style="color:var(--bl);font-weight:700">'+orderObj.tk+'</span> - '+
    orderObj.qty+' cotas - '+type+'<br>'+
    '<span style="color:var(--a);font-size:10px">Agendada para: '+nextPregaoDateStr()+' as 10:00</span>';
  $("aho-modal").style.display="flex";
}

//  Dividendos 
function checkDividends() {
  var today = new Date().toISOString().split("T")[0];
  if (checkedDivDate === today) return; // ja checou hoje
  checkedDivDate = today;

  var held = Object.keys(port);
  if (!held.length) { saveState(); return; }

  // Busca dividendos de todos os ativos em carteira
  var promises = held.map(function(ticker) {
    return fetch(BRAPI+"/quote/"+ticker+"?dividends=true&token="+token)
      .then(function(r){ return r.json(); })
      .then(function(d){
        if (d.error || !d.results || !d.results.length) return null;
        return { ticker: ticker, data: d.results[0] };
      })
      .catch(function(){ return null; });
  });

  Promise.all(promises).then(function(results) {
    var credited = false;
    results.forEach(function(res) {
      if (!res || !res.data) return;
      var ticker = res.ticker;
      var pos = port[ticker];
      if (!pos) return;

      var divList = res.data.dividendsData && res.data.dividendsData.cashDividends;
      if (!divList || !divList.length) return;

      divList.forEach(function(d) {
        // Verifica se a data de pagamento  hoje e se ainda no processamos
        var payDate = (d.paymentDate || d.approvedOn || "").split("T")[0];
        if (payDate !== today) return;

        // Verifica se j creditamos este dividendo
        var divId = ticker+"_"+payDate+"_"+d.rate;
        var alreadyCredited = divs.some(function(x){ return x.id === divId; });
        if (alreadyCredited) return;

        var value = pos.qty * (d.rate || 0);
        if (value <= 0) return;

        bal += value;
        totalDiv += value;
        var divRec = {
          id: divId, ticker: ticker, qty: pos.qty,
          rate: d.rate, value: value,
          date: today, tm: new Date().toLocaleTimeString("pt-BR")
        };
        divs.unshift(divRec);
        if (divs.length > 100) divs.pop();
        notif("Dividendo: +" + R(value) + " (" + ticker + " - R$" + fr(d.rate) + "/cota)");
        credited = true;
      });
    });
    if (credited) saveState();
  }).catch(function(){});
}

//  Ordens pendentes 
function checkPending() {
  if (!pending.length) return;
  if (!isPregaoOpen()) return; // so executa durante pregao
  var keep = [], changed = false;
  for (var i=0; i<pending.length; i++) {
    var o = pending[i];
    if (o.scheduled) { keep.push(o); continue; } // aguarda ativacao no pregao

    var p = prices[o.tk];
    if (!p) { keep.push(o); continue; }

    // Market order agendada: executa imediatamente
    if (o.market) {
      doMarketOrder(o.tk, o.side, o.qty, true);
      changed = true; continue;
    }

    // Limit order: executa quando preo cruzar o limite (qualquer direo)
    // Compra: executa quando p <= lp (mercado caiu at o alvo)
    // Venda: executa quando p >= lp (mercado subiu at o alvo)
    // Se mercado j passou alm do limite, executa no preo de mercado
    var hit = (o.side==="buy" && p<=o.lp) || (o.side==="sell" && p>=o.lp);
    if (!hit) { keep.push(o); continue; }

    var execPrice = p; // executa no preco de mercado quando atingir o limite
    var tot = execPrice * o.qty;
    if (o.side==="buy") {
      if (tot>bal) { notif("Ordem cancelada - saldo insuf. ("+o.tk+")", "err"); changed=true; continue; }
      bal -= tot;
      if (port[o.tk]) { var x=port[o.tk],nq=x.qty+o.qty; port[o.tk]={qty:nq,avgPrice:(x.qty*x.avgPrice+tot)/nq}; }
      else port[o.tk] = {qty:o.qty,avgPrice:execPrice};
      if (!firstTradeDate) firstTradeDate=new Date().toISOString().split("T")[0];
    } else {
      var pos2 = port[o.tk]; if (!pos2||pos2.qty<o.qty) { changed=true; continue; }
      bal += tot;
      var nq2b=pos2.qty-o.qty; if(nq2b===0) delete port[o.tk]; else port[o.tk]={qty:nq2b,avgPrice:pos2.avgPrice};
    }
    trd.unshift({id:Date.now(),tk:o.tk,tp:o.side==="buy"?"C":"V",qty:o.qty,pr:execPrice,tot:tot,
      tm:new Date().toLocaleTimeString("pt-BR"),note:"Lim @ "+fr(o.lp)});
    if (trd.length>200) trd.pop();
    playTradeSound("limit");
    sfxShot(); notif("Ordem limitada executada: "+o.qty+" "+o.tk+" @ "+R(execPrice));
    changed=true;
  }
  pending = keep;
  if (changed) saveState();
}

//  Equity Canvas Chart 
function getEquityPointTimestamp(p) {
  if (!p) return NaN;
  if (typeof p.t !== "undefined" && !isNaN(Number(p.t))) return Number(p.t);
  if (typeof p.ts !== "undefined" && !isNaN(Number(p.ts))) return Number(p.ts);
  if (typeof p.time !== "undefined" && !isNaN(Number(p.time))) return Number(p.time);
  if (p.date) { var d1=new Date(p.date); if (!isNaN(d1.getTime())) return d1.getTime(); }
  if (p.dt) { var d2=new Date(p.dt); if (!isNaN(d2.getTime())) return d2.getTime(); }
  return NaN;
}
function formatEquityLabel(p) {
  var ts=getEquityPointTimestamp(p); if (isNaN(ts)) return "";
  return new Date(ts).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"});
}
function drawEquityChart() {
  var canvas = $("equity-chart");
  if (!canvas) return;
  var parent = canvas.parentElement;
  var W = parent.clientWidth - 28;
  if (W <= 0) return;
  var H = 180;
  var dpr = window.devicePixelRatio || 1;
  canvas.width = W * dpr; canvas.height = H * dpr;
  canvas.style.width = W+"px"; canvas.style.height = H+"px";
  var ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.fillStyle="#090d16"; ctx.fillRect(0,0,W,H);

  // Aggregate: last point per calendar day
  var dailyMap = {};
  (equityHistory || []).forEach(function(p) {
    if (!p || !p.t || isNaN(p.v)) return;
    var d = new Date(Number(p.t));
    var key = d.getFullYear()+"-"+d.getMonth()+"-"+d.getDate();
    if (!dailyMap[key] || Number(p.t) > dailyMap[key].t)
      dailyMap[key] = { t: Number(p.t), v: Number(p.v) };
  });

  var sorted = Object.values(dailyMap).sort(function(a,b){return a.t-b.t;});

  // Fill missing weekdays with previous day value
  var daily = [];
  if (sorted.length > 0) {
    daily.push(sorted[0]);
    for (var di=1; di<sorted.length; di++) {
      var prev = sorted[di-1], curr = sorted[di];
      var d = new Date(prev.t); d.setDate(d.getDate()+1);
      while (d.getTime() < curr.t) {
        var dow = d.getDay();
        if (dow!==0 && dow!==6)
          daily.push({t:d.getTime(), v:prev.v});
        d.setDate(d.getDate()+1);
      }
      daily.push(curr);
    }
  }

  if (daily.length < 2) {
    ctx.fillStyle="#6b8cae"; ctx.font="10px 'JetBrains Mono',monospace"; ctx.textAlign="center";
    ctx.fillText("Aguardando dados suficientes...", W/2, H/2);
    return;
  }

  var PAD_L=8, PAD_R=56, PAD_T=10, PAD_B=22;
  var CW=W-PAD_L-PAD_R, CH=H-PAD_T-PAD_B;
  var n = daily.length;
  var vals = daily.map(function(p){return p.v;});
  var minV = Math.min.apply(null,vals)*0.998;
  var maxV = Math.max.apply(null,vals)*1.002;
  if (goal && goal.target) {
    var goalVal = initialBal*(1+goal.target/100);
    if (goalVal>maxV) maxV=goalVal*1.002;
    if (goalVal<minV) minV=goalVal*0.998;
  }
  var range = maxV-minV || 1;

  function px(v){return PAD_T+CH*(1-(v-minV)/range);}
  function py(i){return PAD_L+CW*(i/(n-1));}

  // Grid lines + Y labels (bright)
  ctx.lineWidth=0.5;
  for (var gi=0; gi<=4; gi++) {
    var gy = PAD_T+(CH/4)*gi;
    ctx.strokeStyle="rgba(255,255,255,.07)";
    ctx.beginPath(); ctx.moveTo(PAD_L,gy); ctx.lineTo(W-PAD_R,gy); ctx.stroke();
    var gval = maxV-(range/4)*gi;
    ctx.fillStyle="#8fb8d8"; ctx.font="bold 9px 'JetBrains Mono',monospace"; ctx.textAlign="left";
    var label = gval>=1000000?(gval/1000000).toFixed(2)+"M":gval>=1000?Math.round(gval/1000)+"k":Math.round(gval)+"";
    ctx.fillText(label, W-PAD_R+4, gy+3);
  }

  // Goal line
  if (goal && goal.target) {
    var gv = initialBal*(1+goal.target/100);
    var gly = px(gv);
    ctx.strokeStyle="rgba(245,158,11,.7)"; ctx.lineWidth=1; ctx.setLineDash([4,4]);
    ctx.beginPath(); ctx.moveTo(PAD_L,gly); ctx.lineTo(W-PAD_R,gly); ctx.stroke();
    ctx.setLineDash([]);
    if ($("legend-goal")) $("legend-goal").style.display="flex";
  }

  // Area fill
  var isUp = daily[n-1].v >= daily[0].v;
  var lineColor = isUp ? "#00d8a0" : "#ff4466";
  var grad = ctx.createLinearGradient(0,PAD_T,0,PAD_T+CH);
  grad.addColorStop(0, isUp?"rgba(0,216,160,.3)":"rgba(255,68,102,.3)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.beginPath();
  ctx.moveTo(py(0),px(daily[0].v));
  for (var j=1;j<n;j++) ctx.lineTo(py(j),px(daily[j].v));
  ctx.lineTo(py(n-1),PAD_T+CH); ctx.lineTo(py(0),PAD_T+CH);
  ctx.closePath(); ctx.fillStyle=grad; ctx.fill();

  // Line
  ctx.strokeStyle=lineColor; ctx.lineWidth=2; ctx.setLineDash([]);
  ctx.beginPath(); ctx.moveTo(py(0),px(daily[0].v));
  for (var k=1;k<n;k++) ctx.lineTo(py(k),px(daily[k].v));
  ctx.stroke();

  // Last dot
  ctx.fillStyle=lineColor;
  ctx.beginPath(); ctx.arc(py(n-1),px(daily[n-1].v),3.5,0,Math.PI*2); ctx.fill();

  // X labels (bright)
  ctx.fillStyle="#8fb8d8"; ctx.font="bold 9px 'JetBrains Mono',monospace";
  ctx.textAlign="center"; ctx.textBaseline="top";
  var lc = Math.min(6,n);
  for (var li=0;li<lc;li++) {
    var lidx = Math.round(li*(n-1)/Math.max(lc-1,1));
    var lpt = daily[lidx];
    var ld = new Date(lpt.t);
    var llbl = ("0"+ld.getDate()).slice(-2)+"/"+ ("0"+(ld.getMonth()+1)).slice(-2);
    ctx.fillText(llbl, PAD_L+(lidx/Math.max(n-1,1))*CW, PAD_T+CH+6);
  }
}

function portValue() {
  var v=0; Object.keys(port).forEach(function(t){ v+=port[t].qty*(prices[t]||0); }); return v;
}

function renderGoalBar() {
  var gb=$("goalbar");
  if (!goal.endDate && !goal.target) { gb.style.display="none"; return; }
  gb.style.display="block";
  var te=bal+portValue(), currPct=((te-initialBal)/initialBal)*100, targetPct=goal.target||0;
  var progress=targetPct>0?Math.min(100,Math.max(0,(currPct/targetPct)*100)):0;
  var color=currPct>=targetPct?"var(--g)":currPct>=0?"var(--a)":"var(--r)";
  $("gb-fill").style.width=progress+"%"; $("gb-fill").style.background=color;
  $("gb-pct").textContent=targetPct+"%";
  $("gb-curr").textContent=(currPct>=0?"+":"")+currPct.toFixed(2)+"% atual"; $("gb-curr").style.color=color;
  if (goal.endDate) {
    var now=new Date(); now.setHours(0,0,0,0);
    var end=new Date(goal.endDate+"T00:00:00");
    var days=Math.ceil((end-now)/86400000);
    $("gb-days").textContent=days>0?days+"d restantes":"ENCERRADO";
    $("gb-days").style.color=days<=7?"var(--r)":"var(--a)";
    $("gb-end").textContent="Meta: "+end.toLocaleDateString("pt-BR");
  } else { $("gb-days").textContent=""; $("gb-end").textContent=""; }
}

function makeTkBtn(t) {
  var p=prices[t]||0, c=pct[t]||0, on=(t===sel);
  var b=document.createElement("button");
  b.className="tk"+(on?" on":"");
  b.dataset.sym=t;
  b.innerHTML='<div class="tks">'+t+'</div><div class="tkp">'+(p>0?fr(p):"...")+
    '</div><div class="tkv" style="color:'+(c>=0?"var(--g)":"var(--r)")+'">'+(c>=0?"+":"")+c.toFixed(2)+'%</div>';
  b.onclick=function(){ sel=t; render(); loadTV(); };
  return b;
}

function renderTickers() {
  var el=$("tks"); el.innerHTML="";
  // Duplicate list x3 for seamless infinite scroll
  for (var pass=0; pass<3; pass++) {
    TAPE_TICKERS.forEach(function(t) {
      el.appendChild(makeTkBtn(t));
    });
  }
  initTickerTape();
}

function renderSB() {
  var p=prices[sel]||0,c=chg[sel]||0,cp=pct[sel]||0;
  $("ssym").textContent=sel; $("snm").textContent=NAMES[sel];
  $("spr").textContent=p>0?fr(p):"--"; $("spr").style.color=c>=0?"var(--g)":"var(--r)";
  $("sch").textContent=(c>=0?"+":"")+fr(Math.abs(c))+" ("+(cp>=0?"+":"")+cp.toFixed(2)+"%)";
  $("sch").style.color=c>=0?"var(--g)":"var(--r)";
}

function renderHdr() {
  var pv=portValue(), te=bal+pv, pnl=te-initialBal;
  $("hp").textContent=R(te);
  $("hpnl").textContent=(pnl>=0?"+":"")+R(Math.abs(pnl))+" ("+(pnl>=0?"+":"")+((pnl/initialBal)*100).toFixed(2)+"%)";
  $("hpnl").style.color=pnl>=0?"var(--g)":"var(--r)";
  $("hb").textContent=R(bal); $("hpv").textContent=R(pv);
}

function renderOrders() {
  var p=prices[sel]||0, isIndex=(sel==="IBOV");
  var open=isPregaoOpen();
  $("osym").textContent=sel;
  $("oprc").textContent=p>0?R(p):"Aguardando...";
  $("oprc").style.color=p>0?(chg[sel]>=0?"var(--g)":"var(--r)"):"var(--tx2)";
  var usePrice=(orderMode==="limit")?(parseFloat($("lmt-price").value)||0):p;
  var total = usePrice>0 ? usePrice*qty : 0;
  $("otot").textContent=total>0?R(total):"--";
  // Balance fields
  if ($("o-bal")) $("o-bal").textContent = R(bal);
  if ($("o-after")) {
    var after = side==="buy" ? bal-total : bal+total;
    $("o-after").textContent = total>0 ? R(after) : "--";
    $("o-after").style.color = (side==="buy" && after<0) ? "var(--r)" : "var(--tx2)";
  }


  // Update exec button text for after-hours
  var execEl=$("exec");
  if (!open && !isIndex) {
    if (side==="buy") {
      execEl.textContent=orderMode==="limit"?"AGENDAR COMPRA LIMITADA":"AGENDAR COMPRA";
    } else {
      execEl.textContent=orderMode==="limit"?"AGENDAR VENDA LIMITADA":"AGENDAR VENDA";
    }
    execEl.style.opacity="0.75";
  } else {
    updateExecBtn();
    execEl.style.opacity="1";
  }

  // IBOV is index only
  var orderCard=$("order-panel").querySelector(".card");
  if(isIndex){ orderCard.style.opacity="0.4"; execEl.disabled=true; }
  else { orderCard.style.opacity="1"; execEl.disabled=false; }

  var pos=port[sel];
  if (pos&&p>0&&!isIndex) {
    var pnl=(p-pos.avgPrice)*pos.qty,pp=((p-pos.avgPrice)/pos.avgPrice)*100;
    $("pbox").style.display="block"; $("plbl").textContent="SUA POSICAO EM "+sel;
    $("pqty").textContent=pos.qty; $("ppm").textContent=R(pos.avgPrice);
    $("ppnl").textContent=(pnl>=0?"+":"")+R(pnl)+" ("+(pp>=0?"+":"")+pp.toFixed(2)+"%)";
    $("ppnl").style.color=pnl>=0?"var(--g)":"var(--r)";
  } else {
    $("pbox").style.display="none";
  }

  // Disable sell / cap quantity if no position or insufficient
  var hasSel = !!port[sel];
  var maxSell = hasSel ? port[sel].qty : 0;

  if (side==="sell" && !isIndex) {
    if (!hasSel) {
      execEl.disabled = true;
      execEl.style.opacity = "0.35";
      execEl.textContent = "SEM POSICAO EM "+sel;
    } else {
      // Cap qty to max owned
      if (qty > maxSell) {
        qty = maxSell;
        $("qinp").value = qty;
        document.querySelectorAll(".pr").forEach(function(b){
          b.classList.toggle("on", +b.dataset.q===qty);
        });
      }
      $("qinp").max = maxSell;
      // Show max available
      var maxHint = $("sell-max-hint");
      if (!maxHint) {
        maxHint = document.createElement("div");
        maxHint.id = "sell-max-hint";
        maxHint.style.cssText = "font-size:9px;color:var(--tx3);margin-top:-8px;margin-bottom:8px;text-align:right;";
        var qinpEl = $("qinp");
        qinpEl.parentNode.insertBefore(maxHint, qinpEl.nextSibling);
      }
      maxHint.textContent = "Max. disponivel: " + maxSell + " cotas";
    }
    $("bsel").style.opacity = !hasSel ? "0.4" : "1";
  } else {
    // Buy side  remove cap and hint
    $("qinp").removeAttribute("max");
    var hint = $("sell-max-hint");
    if (hint) hint.textContent = "";
    $("bsel").style.opacity = "1";
  }
}

function renderPending() {
  var sec=$("pend-sec"),list=$("pend-list");
  if (!pending.length) { sec.style.display="none"; return; }
  sec.style.display="block"; list.innerHTML="";
  pending.forEach(function(o) {
    var e=document.createElement("div"); e.className="pend-item";
    var col=o.side==="buy"?"var(--g)":"var(--r)";
    var bgc=o.side==="buy"?"rgba(0,200,150,.15)":"rgba(240,64,96,.15)";
    e.innerHTML='<div><div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">'+
      '<span class="bdg" style="background:'+bgc+';color:'+col+'">'+(o.side==="buy"?"COMPRA":"VENDA")+'</span>'+
      '<span style="color:var(--bl);font-weight:700;font-size:12px">'+o.tk+'</span></div>'+
      '<div style="font-size:9px;color:var(--tx4)">'+o.qty+' cotas - '+(o.scheduled?(o.market?'A MERCADO na abertura':'AGENDADA limite '+R(o.lp)):'LIMITE '+R(o.lp))+'</div></div>'+
      '<button class="cancel-btn" onclick="cancelPending('+o.id+')">CANCELAR</button>';
    list.appendChild(e);
  });
}

function cancelPending(id) {
  pending=pending.filter(function(o){ return o.id!==id; });
  saveState(); renderPending(); notif("Ordem cancelada");
}

function showSellableTickers() {
  var box=$("ticker-results"), inp=$("ticker-search");
  if(!box||!inp)return;
  var owned=Object.keys(port||{}).filter(function(tk){return port[tk]&&Number(port[tk].qty||0)>0;});
  box.innerHTML="";
  if(!owned.length){
    box.style.display="block";
    box.innerHTML='<div class="ticker-result" style="color:var(--tx3);cursor:default">Nenhum ativo disponível para venda</div>';
    return;
  }
  owned.forEach(function(tk){
    var qtyOwned=Number((port[tk]&&port[tk].qty)||0);
    var price=Number(prices[tk]||0);
    var row=document.createElement("div");
    row.className="ticker-result";
    row.innerHTML=
      '<div><div style="color:var(--bl);font-weight:700;font-size:12px">'+tk+'</div>' +
      '<div style="font-size:9px;color:var(--tx4)">Disponível: '+qtyOwned+' cotas</div></div>' +
      '<div style="text-align:right"><div style="font-size:11px;font-weight:700;color:var(--tx)">'+(price?R(price):"—")+'</div></div>';
    row.onclick=function(){
      sel=tk; qty=qtyOwned; inp.value=tk;
      box.style.display="none";
      if($("qinp"))$("qinp").value=qtyOwned;
      renderOrders(); notif("Selecionado para venda: "+tk);
    };
    box.appendChild(row);
  });
  box.style.display="block";
}
function goToSellFromPortfolio(tk) {
  var pos=port[tk];
  if(!pos||!pos.qty){notif("Sem posição para vender em "+tk,"err");return;}
  sel=tk; side="sell"; qty=Number(pos.qty||0); orderMode="market";
  document.querySelectorAll(".tab").forEach(function(b){b.classList.remove("on");});
  var orderTab=document.querySelector(".tab[data-t='order']");
  if(orderTab)orderTab.classList.add("on");
  document.querySelectorAll(".panel").forEach(function(p){p.classList.remove("on");});
  if($("order-panel"))$("order-panel").classList.add("on");
  if($("bbuy"))$("bbuy").style.cssText="background:var(--bg3);color:var(--tx3);";
  if($("bsel"))$("bsel").style.cssText="background:var(--r);color:#fff;box-shadow:0 0 20px rgba(240,64,96,.35);";
  if($("ot-mkt"))$("ot-mkt").classList.add("on");
  if($("ot-lmt"))$("ot-lmt").classList.remove("on");
  if($("lmt-wrap"))$("lmt-wrap").style.display="none";
  if($("lmt-price"))$("lmt-price").value="";
  if($("qinp"))$("qinp").value=qty;
  renderOrders();
}
function renderPort() {
  var pv=portValue(), pnl=bal+pv-initialBal;
  $("pbal").textContent=R(bal); $("ppv").textContent=R(pv);
  $("pdiv").textContent=R(totalDiv);
  $("pres").textContent=(pnl>=0?"+":"")+R(pnl); $("pres").style.color=pnl>=0?"var(--g)":"var(--r)";
  try { drawEquityChart(); } catch(e) {}
  var l=$("plist"); l.innerHTML="";
  if (!Object.keys(port).length) { l.innerHTML='<div class="empty"><div style="font-size:36px;margin-bottom:10px">&#128235;</div>Carteira vazia.</div>'; return; }
  Object.keys(port).forEach(function(t) {
    var pos=port[t],p=prices[t]||0,pnl2=(p-pos.avgPrice)*pos.qty,pp=((p-pos.avgPrice)/pos.avgPrice)*100,dc=pct[t]||0;
    var e=document.createElement("div"); e.className="ac";
    e.style.border="1px solid "+(pnl2>=0?"rgba(0,200,150,.15)":"rgba(240,64,96,.15)");
    e.innerHTML='<div style="display:flex;justify-content:space-between;margin-bottom:8px">'+
      '<div><span style="color:var(--bl);font-weight:700;font-size:14px">'+t+'</span>'+
      '<span style="color:var(--tx4);font-size:10px;margin-left:7px">'+pos.qty+' cotas</span></div>'+
      '<div style="text-align:right"><div style="font-weight:700;font-size:13px">'+R(p*pos.qty)+'</div>'+
      '<div style="font-size:10px;color:'+(pnl2>=0?"var(--g)":"var(--r)")+';font-weight:700">'+(pnl2>=0?"+":"")+R(pnl2)+' ('+(pp>=0?"+":"")+pp.toFixed(2)+'%)</div></div></div>'+
      '<div style="display:flex;justify-content:space-between;font-size:10px;color:var(--tx4)">'+
      '<span>PM:<span style="color:var(--tx3);margin-left:3px">'+R(pos.avgPrice)+'</span></span>'+
      '<span>Atual:<span style="color:'+(dc>=0?"var(--g)":"var(--r)")+';margin-left:3px">'+R(p)+'</span></span>'+
      '<span>Dia:<span style="color:'+(dc>=0?"var(--g)":"var(--r)")+';margin-left:3px">'+(dc>=0?"+":"")+dc.toFixed(2)+'%</span></span></div>';
    // Sell button
    var sb2 = document.createElement("button");
    sb2.style.cssText = "width:100%;padding:7px;background:rgba(240,64,96,.1);border:1px solid rgba(240,64,96,.35);border-radius:6px;color:var(--r);font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;margin-top:8px";
    sb2.textContent = "VENDER " + t;
    (function(tk, qty2){
      sb2.onclick = function(e) {
        e.preventDefault(); e.stopPropagation();
        goToSellFromPortfolio(tk);
      };
    })(t, pos.qty);
    e.appendChild(sb2);
    l.appendChild(e);
  });
}

function renderHist() {
  // Dividends
  var ds=$("div-sec"),dl=$("div-list");
  if (divs.length) {
    ds.style.display="block"; dl.innerHTML="";
    divs.forEach(function(d) {
      var e=document.createElement("div"); e.className="div-item";
      e.innerHTML='<div><div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">'+
        '<span class="bdg" style="background:rgba(0,200,150,.15);color:var(--g)">DIVIDENDO</span>'+
        '<span style="color:var(--bl);font-weight:700;font-size:12px">'+d.ticker+'</span></div>'+
        '<div style="font-size:9px;color:var(--tx4)">'+d.qty+' cotas x R$'+fr(d.rate)+'</div></div>'+
        '<div style="text-align:right"><div style="font-weight:700;font-size:12px;color:var(--g)">+'+R(d.value)+'</div>'+
        '<div style="font-size:9px;color:var(--tx4)">'+d.date+'</div></div>';
      dl.appendChild(e);
    });
  } else ds.style.display="none";

  // Trades
  $("hcnt").textContent=trd.length+" OPERAC"+(trd.length===1?"AO":"OES");
  var l=$("hlist"); l.innerHTML="";
  if (!trd.length) { l.innerHTML='<div class="empty"><div style="font-size:36px;margin-bottom:10px">&#128203;</div>Nenhuma operacao.</div>'; return; }
  trd.forEach(function(t) {
    var col=t.tp==="C"?"var(--g)":"var(--r)", bgc=t.tp==="C"?"rgba(0,200,150,.15)":"rgba(240,64,96,.15)";
    var e=document.createElement("div"); e.className="ti";
    e.style.borderLeft="2px solid "+col;
    e.innerHTML='<div><div style="display:flex;align-items:center;gap:7px;margin-bottom:3px">'+
      '<span class="bdg" style="background:'+bgc+';color:'+col+'">'+(t.tp==="C"?"COMPRA":"VENDA")+'</span>'+
      '<span style="color:var(--bl);font-weight:700;font-size:12px">'+t.tk+'</span>'+
      (t.note?'<span style="font-size:8px;color:var(--a)">&#127919;</span>':'')+
      '</div><div style="font-size:10px;color:var(--tx4)">'+t.qty+' cotas @ '+R(t.pr)+(t.note?' - '+t.note:'')+'</div></div>'+
      '<div style="text-align:right"><div style="font-weight:700;font-size:12px">'+R(t.tot)+'</div>'+
      '<div style="font-size:9px;color:var(--tx4)">'+t.tm+'</div></div>';
    l.appendChild(e);
  });
}

function render() {
  try { renderHdr(); } catch(e) {}
  try { maybePushStats(); } catch(e) {}
  try { renderTickers(); } catch(e) {}
  try { renderSB(); } catch(e) {}
  try { renderOrders(); } catch(e) {}
  try { renderPending(); } catch(e) {}
  try { renderPort(); } catch(e) {}
  try { renderHist(); } catch(e) {}
  try { renderGoalBar(); } catch(e) {}
}

//  Trading 
function doMarketOrder(tk, sd, q, isScheduled) {
  var p = prices[tk]; if (!p) { notif("Sem cotacao","err"); return; }
  var tot = p*q;
  if (sd==="buy") {
    if (tot>bal) { notif("Saldo insuficiente","err"); return; }
    bal-=tot;
    if (port[tk]) { var x=port[tk],nq=x.qty+q; port[tk]={qty:nq,avgPrice:(x.qty*x.avgPrice+tot)/nq}; }
    else port[tk]={qty:q,avgPrice:p};
    trd.unshift({id:Date.now(),tk:tk,tp:"C",qty:q,pr:p,tot:tot,
      tm:new Date().toLocaleTimeString("pt-BR"),
      note:isScheduled?"Agendada":""});
    if (!firstTradeDate) { firstTradeDate=new Date().toISOString().split("T")[0]; }
    playTradeSound("buy");
    sfxBoltShot(); notif("Compra executada: "+q+" "+tk+" @ "+R(p));
  } else {
    var pos=port[tk]; if(!pos||pos.qty<q){notif("Posicao insuficiente","err");return;}
    bal+=tot;
    var nq2=pos.qty-q; if(nq2===0) delete port[tk]; else port[tk]={qty:nq2,avgPrice:pos.avgPrice};
    trd.unshift({id:Date.now(),tk:tk,tp:"V",qty:q,pr:p,tot:tot,
      tm:new Date().toLocaleTimeString("pt-BR"),
      note:isScheduled?"Agendada":""});
    playTradeSound("sell");
    (function(){var pos2=port[tk]||{avgPrice:p};if((p-pos2.avgPrice)>=0)sfxHitPlate();else sfxHitDirt();})(); notif("Venda executada: "+q+" "+tk+" @ "+R(p));
  }
  if (trd.length>200) trd.pop();
  saveState(); render();
}

function execOrder() {
  if (sel==="IBOV") { notif("IBOV e indice - nao e possivel operar","err"); return; }
  var p=prices[sel]; if (!p) { notif("Sem cotacao disponivel","err"); return; }

  var open = isPregaoOpen();

  //  Limit order 
  if (orderMode==="limit") {
    var lp=parseFloat($("lmt-price").value);
    if (!lp||lp<=0) { notif("Informe o preco limite","err"); return; }
    if (side==="buy"&&lp*qty>bal) { notif("Saldo insuficiente","err"); return; }
    if (side==="sell") {
      var sp=port[sel]; if(!sp){notif("Voce nao possui "+sel+" em carteira","err");return;}
      if(qty>sp.qty){notif("Quantidade excede posicao (max: "+sp.qty+")","err");qty=sp.qty;$("qinp").value=qty;renderOrders();return;}
    }
    var orderObj = {id:Date.now(),tk:sel,side:side,qty:qty,lp:lp};
    if (!open) {
      // Show after-hours modal for scheduling
      orderObj.scheduled=true;
      showAHO(orderObj);
      return;
    }
    pending.push(orderObj);
    saveState(); render();
    playTradeSound("pending");
    sfxBolt(); notif("Ordem limitada enviada: "+qty+" "+sel+" @ "+R(lp)); return;
  }

  //  Market order 
  if (!open) {
    // Offer to schedule as market order at next open
    sfxBolt(); showAHO({id:Date.now(),tk:sel,side:side,qty:qty,lp:null,scheduled:true,market:true});
    return;
  }
  doMarketOrder(sel,side,qty,false);
}

//  UI wiring 
//  Ticker tape auto-scroll 
var tapeX = 0;
var tapeSpeed = 1.2;     // px per frame
var tapePaused = false;
var tapeDragging = false;
var tapeDragStartX = 0;
var tapeDragStartTapeX = 0;
var tapeRAF = null;
var tapeOneSetW = 0;     // width of one full set of tickers

function initTickerTape() {
  var wrap = $("tks-wrap");
  var el   = $("tks");
  if (!wrap || !el) return;

  // Wait for layout
  setTimeout(function() {
    // One set = total items / 3
    var items = el.querySelectorAll(".tk");
    var count = items.length;
    var oneSet = count / 3;
    tapeOneSetW = 0;
    for (var i=0; i<oneSet; i++) {
      tapeOneSetW += items[i].offsetWidth + 5; // 5 = gap
    }
    // Start from middle set so we can scroll both ways
    tapeX = -tapeOneSetW;
    el.style.transform = "translateX("+tapeX+"px)";
    cancelAnimationFrame(tapeRAF);
    tapeLoop();
  }, 100);

  // Touch events
  wrap.addEventListener("touchstart", function(e) {
    tapePaused   = true;
    tapeDragging = true;
    tapeDragStartX     = e.touches[0].clientX;
    tapeDragStartTapeX = tapeX;
  }, {passive:true});

  wrap.addEventListener("touchmove", function(e) {
    if (!tapeDragging) return;
    var dx = e.touches[0].clientX - tapeDragStartX;
    tapeX = tapeDragStartTapeX + dx;
    $("tks").style.transform = "translateX("+tapeX+"px)";
  }, {passive:true});

  wrap.addEventListener("touchend", function() {
    tapeDragging = false;
    tapePaused   = false; // resume auto-scroll
  }, {passive:true});
}

function tapeLoop() {
  if (!tapePaused) {
    tapeX -= tapeSpeed;
    var el = $("tks");
    if (!el) return;
    // Seamless loop: when scrolled past one full set, jump back
    if (tapeX < -(tapeOneSetW * 2)) tapeX += tapeOneSetW;
    if (tapeX > 0) tapeX -= tapeOneSetW;
    el.style.transform = "translateX("+tapeX+"px)";
  }
  tapeRAF = requestAnimationFrame(tapeLoop);
}

function updateExecBtn() {
  var e=$("exec");
  if (side==="buy") {
    e.style.cssText="width:100%;padding:14px;border-radius:10px;background:linear-gradient(135deg,var(--g),#00a078);color:#fff;font-weight:700;font-size:15px;letter-spacing:1px;box-shadow:0 4px 24px rgba(0,200,150,.35);border:none;margin-bottom:12px;";
    e.textContent=orderMode==="limit"?"ENVIAR COMPRA LIMITADA":"EXECUTAR COMPRA";
  } else {
    e.style.cssText="width:100%;padding:14px;border-radius:10px;background:linear-gradient(135deg,var(--r),#cc2233);color:#fff;font-weight:700;font-size:15px;letter-spacing:1px;box-shadow:0 4px 24px rgba(240,64,96,.35);border:none;margin-bottom:12px;";
    e.textContent=orderMode==="limit"?"ENVIAR VENDA LIMITADA":"EXECUTAR VENDA";
  }
}

//  News system 
var newsCache = (function(){
  try { var n=JSON.parse(localStorage.getItem("hb_news_v1")||"[]"); return Array.isArray(n)?n:[]; }
  catch(e){ return []; }
})();
var newsTapeItems = [];
var newsTapeX = 0;
var newsTapeOneW = 0;
var newsTapeRAF = null;
var newsTapePaused = false;
var newsTapeDragging = false;
var newsTapeDragStartX = 0;
var newsTapeDragStartTapeX = 0;
var newsLastFetch = 0;
var NEWS_REFRESH = 15 * 60 * 1000; // 15 min during pregao
var focusNewsId = null;
var autoExpandId = null; // auto-expand summary when coming from tape // news to scroll to when opening tab

// RSS feeds via Claude proxy (CORS bypass)
var NEWS_SOURCES = [
  // Macro
  {url:"https://www.bcb.gov.br/api/feed/pt-br/noticias", label:"BC", type:"macro"},
  {url:"https://www.gov.br/fazenda/pt-br/assuntos/noticias/RSS", label:"FAZENDA", type:"macro"},
  {url:"https://www.cvm.gov.br/noticias/rss.html", label:"CVM", type:"macro"},
  // Empresas / B3
  {url:"https://www.infomoney.com.br/feed/", label:"INFOMONEY", type:"company"},
  {url:"https://valoreconomico.globo.com/rss/mercados/", label:"VALOR", type:"company"}
];

var TICKER_KEYS = TICKERS.concat(["IBOVESPA","IBOV","B3","BOVESPA"]);

function fetchNews() {
  var now = Date.now();
  if (now - newsLastFetch < NEWS_REFRESH) return;
  newsLastFetch = now;

  // rss2json.com converts RSS to JSON - reliable and free
  var RSS2JSON = "https://api.rss2json.com/v1/api.json?rss_url=";

  var feeds = [
    // Brasil
    {url:"https://www.infomoney.com.br/feed/",                          label:"InfoMoney",  type:"company", lang:"pt"},
    {url:"https://valoreconomico.globo.com/rss/financas/",              label:"Valor",      type:"company", lang:"pt"},
    {url:"https://agenciabrasil.ebc.com.br/rss/economia/feed.xml",      label:"Ag.Brasil",  type:"macro",   lang:"pt"},
    {url:"https://exame.com/invest/feed/",                              label:"Exame",      type:"company", lang:"pt"},
    {url:"https://www.moneytimes.com.br/feed/",                         label:"MoneyTimes", type:"macro",   lang:"pt"},
    // Internacional
    {url:"https://www.cnbc.com/id/10000664/device/rss/rss.html",        label:"CNBC",       type:"macro",   lang:"en"},
    {url:"https://feeds.bbci.co.uk/news/business/rss.xml",              label:"BBC",        type:"macro",   lang:"en"},
    {url:"https://feeds.reuters.com/reuters/businessNews",              label:"Reuters",    type:"macro",   lang:"en"},
    {url:"https://rss.dw.com/rdf/rss-en-bus",                          label:"DW",         type:"macro",   lang:"en"},
    {url:"https://rss.cnn.com/rss/money_news_international.rss",        label:"CNN",        type:"macro",   lang:"en"}
  ];

  var allNews = [];
  var completed = 0;
  var total = feeds.length;

  function tryDone() {
    completed++;
    if (completed < total) return;
    allNews.sort(function(a,b){ return b.ts - a.ts; });
    var seen = {};
    newsCache = allNews.filter(function(n) {
      var key = n.title.slice(0,40);
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    }).slice(0, 30);
    newsCache.forEach(function(n, i){ n.id = i+1; });
    try { localStorage.setItem("hb_news_v1", JSON.stringify(newsCache)); } catch(e){}

    var loading = $("news-loading");
    if (loading) loading.style.display = "none";

    if (!newsCache.length) {
      var emptyEl = $("news-empty");
      if (emptyEl) emptyEl.style.display = "block";
      return;
    }
    buildNewsTape();
    renderNewsTab();
    // Restart tape animation
    cancelAnimationFrame(newsTapeRAF);
    newsTapeLoop();
  }

  feeds.forEach(function(feed) {
    fetch(RSS2JSON + encodeURIComponent(feed.url) + "&count=10")
      .then(function(r){ return r.json(); })
      .then(function(data) {
        var items = (data.items || []);
        items.forEach(function(item) {
          var title = (item.title || "").trim();
          var link  = item.link || item.guid || "";
          var pubDate = item.pubDate || "";
          if (!title || title.length < 10) return;

          // Relevance filter
          var lower = title.toLowerCase();
          var isIntl = feed.lang === "en";

          // BLOCK: marketing, lifestyle
          var blocked = /iphone|swarovski|bracelete|vinho|celular|notebook|desconto|oferta|promocao|black friday|cupom/.test(lower);
          if (blocked) return;

          var relevant;
          if (isIntl) {
            // International: finance, economy, geopolitics
            relevant = /market|stock|economy|gdp|inflation|fed|rate|bank|trade|tariff|bond|oil|gold|dollar|euro|china|dollar|recession|growth|debt|deficit|war|conflict|sanction|geopolit|ukraine|middle east|opec|crude|treasury|nasdaq|dow|s&p|wall street|interest|central bank|imf|world bank|emerging/.test(lower);
          } else {
            // Brazil: financial keywords
            relevant = /bolsa|ibovespa|selic|banco central|juros|cvm|acoes|acao|mercado|b3|petrobras|vale|itau|bradesco|ambev|weg|embraer|dividendo|resultado|lucro|receita|economia|inflacao|cambio|dolar|credito|bovespa|investimento|fiscal|fazenda|pib|copom|tesouro|fundo|fii|etf|commodities|petroleo|exportacao/.test(lower);
          }
          if (!relevant) return;

          // Detect ticker mention
          var ticker = "";
          TICKERS.forEach(function(t) {
            if (title.toUpperCase().indexOf(t) >= 0) ticker = t;
          });

          var ts = pubDate ? new Date(pubDate).getTime() : (Date.now() - allNews.length*60000);
          var mins = Math.floor((Date.now() - ts) / 60000);
          var timeStr = mins < 1 ? "agora" :
                        mins < 60 ? "ha " + mins + "min" :
                        mins < 1440 ? "ha " + Math.floor(mins/60) + "h" :
                        "ha " + Math.floor(mins/1440) + "d";

          var desc = (item.description || item.content || item.summary || "").replace(/<[^>]+>/g,"").trim();
          if (desc.length > 800) desc = desc.slice(0, 800) + "...";
          allNews.push({
            title: title, source: feed.label,
            type: ticker ? "company" : feed.type,
            ticker: ticker, time: timeStr, url: link, ts: ts,
            desc: desc, lang: feed.lang || "pt"
          });
        });
        tryDone();
      })
      .catch(function(){ tryDone(); });
  });
}


// ── News summary ─────────────────────────────────────────────────────────────
function showSummaryInCard(cardEl, item) {
  var btn = cardEl.querySelector(".news-expand-btn");
  var box = cardEl.querySelector(".news-summary-box");
  if (!btn || !box) return;
  box.style.display = "block";
  box.innerHTML = "";

  function renderSummary(text) {
    var p = document.createElement("p");
    p.style.cssText = "font-size:11px;color:var(--tx2);line-height:1.8;margin-bottom:10px;white-space:pre-line";
    p.textContent = text;
    box.appendChild(p);
    if (item.url) {
      var a = document.createElement("a");
      a.href = item.url;
      a.target = "_blank";
      a.style.cssText = "font-size:10px;color:var(--bl);font-weight:700;text-decoration:none;display:block;margin-top:4px";
      a.textContent = "Ler noticia completa";
      box.appendChild(a);
    }
    btn.textContent = "Fechar";
    btn.disabled = false;
  }

  // If RSS already gave us description, use it
  if (item.desc && item.desc.length > 80 && item.desc !== item.title) {
    renderSummary(item.desc);
    return;
  }

  // Otherwise fetch article via proxy
  btn.textContent = "Carregando...";
  btn.disabled = true;
  var loading = document.createElement("span");
  loading.style.cssText = "font-size:11px;color:var(--tx3)";
  loading.textContent = "Buscando conteudo...";
  box.appendChild(loading);

  if (!item.url) { box.innerHTML = ""; renderSummary(item.title); return; }

  fetch("https://api.allorigins.win/get?url=" + encodeURIComponent(item.url))
    .then(function(r) { return r.json(); })
    .then(function(data) {
      var html = data.contents || "";
      box.innerHTML = "";
      if (!html) { renderSummary(item.title); return; }
      var parser = new DOMParser();
      var doc = parser.parseFromString(html, "text/html");
      ["script","style","nav","header","footer","aside","figure","iframe"].forEach(function(tag) {
        var els = doc.querySelectorAll(tag);
        for (var i = els.length - 1; i >= 0; i--) els[i].parentNode.removeChild(els[i]);
      });
      var paras = doc.querySelectorAll("p, article p, .content p, .article-body p");
      var texts = [];
      for (var i = 0; i < paras.length; i++) {
        var t = paras[i].textContent.trim();
        if (t.length > 80 && texts.indexOf(t) === -1) texts.push(t);
        if (texts.length >= 5) break;
      }
      if (!texts.length) { renderSummary(item.title); return; }
      var summary = texts.join("\n\n");
      if (summary.length > 900) summary = summary.slice(0, 900) + "...";
      renderSummary(summary);
    })
    .catch(function() { box.innerHTML = ""; renderSummary(item.title); });
}

function fetchSummary(item, cardEl) {
  var btn = cardEl.querySelector(".news-expand-btn");
  var box = cardEl.querySelector(".news-summary-box");
  if (!btn || !box) return;
  // Toggle
  if (box.style.display === "block") {
    box.style.display = "none";
    btn.textContent = "Ver resumo";
    return;
  }
  showSummaryInCard(cardEl, item);
}


function renderNewsTab() {
  var hdr  = document.getElementById("news-hdr");
  var list = document.getElementById("news-list");
  if (!list) return;

  var n = newsCache.length;
  if (hdr) hdr.textContent = n + " NOTICIAS";
  list.innerHTML = "";

  if (!n) {
    list.innerHTML = '<div class="empty">Buscando noticias...</div>';
    return;
  }

  var savedAutoExpand = autoExpandId;
  var savedFocus = focusNewsId;

  newsCache.forEach(function(item) {
    var e = document.createElement("div");
    e.className = "ti";
    e.id = "ni-" + item.id;
    var tc = item.type === "macro" ? "var(--a)" : "var(--bl)";
    e.style.cssText = "border-left:2px solid "+tc+";flex-direction:column;align-items:flex-start;cursor:default;margin-bottom:8px;";

    // Top row
    var top = document.createElement("div");
    top.style.cssText = "display:flex;justify-content:space-between;width:100%;margin-bottom:5px";
    var badge = document.createElement("span");
    badge.className = "bdg";
    badge.style.cssText = "background:rgba(255,255,255,.06);color:"+tc;
    badge.textContent = item.ticker || item.source || "?";
    var time = document.createElement("span");
    time.style.cssText = "font-size:9px;color:var(--tx4)";
    time.textContent = item.time || "";
    top.appendChild(badge);
    top.appendChild(time);

    // Title
    var title = document.createElement("div");
    title.style.cssText = "font-size:12px;color:var(--tx);font-weight:600;line-height:1.5;margin-bottom:6px";
    title.textContent = item.title || "";

    // Expand button
    var btn = document.createElement("button");
    btn.className = "news-expand-btn";
    btn.style.cssText = "background:rgba(96,165,250,.1);border:1px solid rgba(96,165,250,.3);border-radius:5px;color:var(--bl);font-size:10px;font-weight:700;padding:3px 10px;cursor:pointer;margin-bottom:4px;font-family:inherit";
    btn.textContent = "Ver resumo";

    // Summary box
    var box = document.createElement("div");
    box.className = "news-summary-box";
    box.style.cssText = "display:none;background:var(--bg);border-radius:6px;padding:10px;margin-top:4px;width:100%;border:1px solid var(--bd2)";

    e.appendChild(top);
    e.appendChild(title);
    e.appendChild(btn);
    e.appendChild(box);

    (function(it, card, b){ 
      b.onclick = function(){ fetchSummary(it, card); }; 
    })(item, e, btn);

    list.appendChild(e);
  });

  // Scroll to focused item
  if (savedFocus || savedAutoExpand) {
    var targetId = savedAutoExpand || savedFocus;
    focusNewsId = null;
    autoExpandId = null;
    setTimeout(function() {
      var el = document.getElementById("ni-" + targetId);
      if (!el) return;
      el.scrollIntoView({behavior:"smooth", block:"start"});
      // Auto-expand summary if coming from tape
      if (savedAutoExpand) {
        var targetItem = null;
        for (var i = 0; i < newsCache.length; i++) {
          if (newsCache[i].id === savedAutoExpand) { targetItem = newsCache[i]; break; }
        }
        if (targetItem) showSummaryInCard(el, targetItem);
      }
    }, 150);
  }
}


function openNewsUrl(url) {
  if (url && url.indexOf("http") === 0) window.open(url, "_blank");
}


function buildNewsTape() {
  var el = $("news-tape");
  if (!el || !newsCache.length) return;

  var items = newsCache.slice(0, 10); // 10 in tape
  newsTapeItems = items;
  el.innerHTML = "";

  // Build 3x for seamless loop
  for (var pass=0; pass<3; pass++) {
    items.forEach(function(n) {
      var span = document.createElement("span");
      span.className = "news-tape-item";
      var tagColor = n.type==="macro" ? "#f59e0b" : "#60a5fa";
      var isEN = (n.lang === "en");
      var tag = n.ticker || n.source;
      if (isEN) tag = "[EN] " + tag;
      span.textContent = '[' + tag + '] ' + n.title + '  -  ';
      span.dataset.newsId = n.id;
      span.onclick = function() {
        var nid = parseInt(span.dataset.newsId);
        focusNewsId = nid;
        autoExpandId = nid; // auto-expand this news summary
        document.querySelectorAll(".tab").forEach(function(b){ b.classList.remove("on"); });
        document.querySelectorAll(".panel").forEach(function(p){ p.classList.remove("on"); });
        $("news-panel").classList.add("on");
        var newsTab = document.querySelector(".tab[data-t='news']");
        if (newsTab) newsTab.classList.add("on");
        $("pb").style.display = "none";
        setTimeout(function(){ renderNewsTab(); }, 50);
      };
      el.appendChild(span);
    });
  }

  // Init tape scroll
  setTimeout(function() {
    var children = el.querySelectorAll(".news-tape-item");
    var oneSet = Math.floor(children.length / 3);
    newsTapeOneW = 0;
    for (var i=0; i<oneSet; i++) newsTapeOneW += children[i].offsetWidth;
    newsTapeX = -newsTapeOneW;
    el.style.transform = "translateX("+newsTapeX+"px)";
    cancelAnimationFrame(newsTapeRAF);
    newsTapeLoop();
  }, 200);
}

function newsTapeLoop() {
  if (!newsTapePaused) {
    newsTapeX -= 0.8;
    var el = $("news-tape");
    if (el) {
      if (newsTapeX < -(newsTapeOneW*2)) newsTapeX += newsTapeOneW;
      if (newsTapeX > 0) newsTapeX -= newsTapeOneW;
      el.style.transform = "translateX("+newsTapeX+"px)";
    }
  }
  newsTapeRAF = requestAnimationFrame(newsTapeLoop);
}

function initNewsTape() {
  var wrap = $("news-tape-wrap");
  if (!wrap) return;
  wrap.addEventListener("touchstart", function(e) {
    newsTapePaused = true;
    newsTapeDragging = true;
    newsTapeDragStartX = e.touches[0].clientX;
    newsTapeDragStartTapeX = newsTapeX;
  }, {passive:true});
  wrap.addEventListener("touchmove", function(e) {
    if (!newsTapeDragging) return;
    newsTapeX = newsTapeDragStartTapeX + (e.touches[0].clientX - newsTapeDragStartX);
    var el = $("news-tape");
    if (el) el.style.transform = "translateX("+newsTapeX+"px)";
  }, {passive:true});
  wrap.addEventListener("touchend", function() {
    newsTapeDragging = false;
    newsTapePaused = false;
  }, {passive:true});
}

//  Ticker quick search 
function initTickerSearch() {
  var input = $("ticker-search");
  var results = $("ticker-results");
  if (!input || !results) return;

  input.addEventListener("input", function() {
    var q = input.value.trim().toUpperCase();
    results.innerHTML = "";

    if (side === "sell" && q.length < 1) {
      showSellableTickers();
      return;
    }

    if (q.length < 1) {
      results.style.display = "none";
      return;
    }

    var sourceList = side === "sell"
      ? Object.keys(port || {}).filter(function(t) {
          return port[t] && Number(port[t].qty || 0) > 0;
        })
      : DISPLAY_TICKERS;

    var matches = sourceList.filter(function(t) {
      return t.indexOf(q) === 0 || (NAMES[t] && NAMES[t].toUpperCase().indexOf(q) >= 0);
    }).slice(0, 8);

    if (!matches.length) {
      if (side === "sell" && q.length < 1) { showSellableTickers(); }
      else { results.style.display = "none"; }
      return;
    }

    matches.forEach(function(t) {
      var qtyOwned = Number((port[t] && port[t].qty) || 0);
      var p = Number(prices[t] || 0);
      var c = Number(pct[t] || 0);
      var el = document.createElement("div");
      el.className = "ticker-result";

      if (side === "sell") {
        el.innerHTML =
          '<div><div style="color:var(--bl);font-weight:700;font-size:12px;letter-spacing:1px">'+t+'</div>' +
          '<div style="font-size:9px;color:var(--tx4)">Disponível: '+qtyOwned+' cotas</div></div>' +
          '<div style="text-align:right"><div style="font-weight:700;font-size:11px;color:var(--tx)">'+(p>0?R(p):"--")+'</div></div>';
        el.onclick = function() {
          sel=t; qty=qtyOwned; input.value=t;
          results.style.display="none";
          if($("qinp"))$("qinp").value=qtyOwned;
          renderOrders(); notif("Selecionado para venda: "+t);
        };
      } else {
        el.innerHTML =
          '<div><span style="color:var(--bl);font-weight:700;font-size:13px;letter-spacing:1px">'+t+'</span>' +
          '<span style="color:var(--tx4);font-size:10px;margin-left:8px">'+(NAMES[t]||"")+'</span></div>' +
          '<div style="text-align:right">' +
          '<div style="font-weight:700;font-size:12px;color:'+(p>0?(c>=0?"var(--g)":"var(--r)"):"var(--tx3)")+'">'+(p>0?fr(p):"--")+'</div>' +
          (p>0?'<div style="font-size:9px;color:'+(c>=0?"var(--g)":"var(--r)") + '">'+(c>=0?"+":"")+c.toFixed(2)+'%</div>':"")+
          '</div>';
        el.onclick = function() {
          sel=t; input.value=""; results.style.display="none";
          render(); loadTV();
          document.querySelectorAll(".tab").forEach(function(b){b.classList.remove("on");});
          document.querySelectorAll(".panel").forEach(function(pn){pn.classList.remove("on");});
          $("order-panel").classList.add("on");
          document.querySelector(".tab[data-t='order']").classList.add("on");
        };
      }
      results.appendChild(el);
    });
    results.style.display = "block";
  });

  input.onfocus = function() {
    if (side === "sell") showSellableTickers();
  };

  document.addEventListener("touchstart", function(e) {
    if (!input.contains(e.target) && !results.contains(e.target)) {
      results.style.display = "none";
    }
  }, { passive: true });

  input.addEventListener("keydown", function(e) {
    if (e.key === "Enter" && results.children.length > 0) results.children[0].click();
  });
}

function buildTapePicker() {
  var picker = document.getElementById("tape-picker");
  var countEl = document.getElementById("tape-count");
  if (!picker) return;
  picker.innerHTML = "";

  // Note about pinned tickers
  var note = document.createElement("div");
  note.style.cssText = "font-size:9px;color:var(--g);margin-bottom:8px;padding:5px 8px;background:rgba(0,200,150,.08);border-radius:5px;border:1px solid rgba(0,200,150,.2)";
  note.textContent = "IBOV e USD/BRL sao fixos e sempre aparecem no tape.";
  picker.appendChild(note);

  var segments = [
    { label: "ACOES IBOVESPA", color: "var(--bl)", tickers: [
      "PETR4","PETR3","VALE3","ITUB4","BBDC4","BBAS3","ABEV3","WEGE3","RENT3","PRIO3",
      "B3SA3","EMBJ3","RADL3","SUZB3","VIVT3","EQTL3","RDOR3","UGPA3","ELET3","ELET6",
      "HAPV3","TOTS3","CPLE6","ENEV3","CSAN3","LREN3","MGLU3","BEEF3","BRFS3","CYRE3",
      "FLRY3","GGBR4","GOAU4","HYPE3","JBSS3","KLBN11","MRVE3","MULT3","RAIL3","SBSP3",
      "TAEE11","TIMS3","TRPL4","USIM5","YDUQ3","NTCO3","POMO4"
    ]},
    { label: "ETFs", color: "var(--a)", tickers: [
      "BOVA11","SMAL11","IVVB11","DOLA11","GOLD11","HASH11","PIBB11","SPXI11","BBSD11","EURP11"
    ]},
    { label: "BDRs", color: "#a78bfa", tickers: [
      "BERK34","AAPL34","AMZO34","GOGL34","MSFT34","NVDC34","TSLA34","META34","NFLX34","GOOGL34"
    ]}
  ];

  // Non-pinned already selected
  var alreadySelected = TAPE_TICKERS.filter(function(t){
    return PINNED_TICKERS.indexOf(t) === -1;
  });

  var updateCount = function() {
    var n = picker.querySelectorAll("input[type=checkbox]:checked").length;
    if (countEl) countEl.textContent = n;
  };

  segments.forEach(function(seg) {
    var hdr = document.createElement("div");
    hdr.style.cssText = "font-size:9px;font-weight:700;color:"+seg.color+";letter-spacing:2px;margin:10px 0 6px;width:100%";
    hdr.textContent = seg.label;
    picker.appendChild(hdr);

    seg.tickers.forEach(function(t) {
      // Skip pinned - they are always in tape
      if (PINNED_TICKERS.indexOf(t) >= 0) return;
      var isOn = alreadySelected.indexOf(t) >= 0;

      var chip = document.createElement("div");
      chip.style.cssText = "display:inline-flex;align-items:center;padding:4px 10px;border-radius:5px;font-size:10px;font-weight:700;cursor:pointer;margin:2px;border:1px solid "+(isOn?"#1e4a80":"var(--bd)")+";background:"+(isOn?"#0d2040":"transparent")+";color:"+(isOn?"var(--bl)":"var(--tx3)")+";";

      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.value = t;
      cb.checked = isOn;
      cb.style.display = "none";
      chip.appendChild(cb);
      chip.appendChild(document.createTextNode(t));

      chip.onclick = function() {
        var total = picker.querySelectorAll("input[type=checkbox]:checked").length;
        if (!cb.checked && total >= 18) {
          notif("Maximo 18 (+ IBOV e USD/BRL fixos)","err");
          return;
        }
        cb.checked = !cb.checked;
        chip.style.border = cb.checked ? "1px solid #1e4a80" : "1px solid var(--bd)";
        chip.style.background = cb.checked ? "#0d2040" : "transparent";
        chip.style.color = cb.checked ? "var(--bl)" : "var(--tx3)";
        updateCount();
      };

      picker.appendChild(chip);
    });
  });

  updateCount();
}


// ── Profile system ────────────────────────────────────────────────────────────
function showProfileScreen() {
  var soloId = ensureSoloProfile();
  if (soloId) {
    localStorage.setItem(LS_PROFILE, soloId);
    setActiveScreen("ma");
    loadSoloFromFirebase().then(function(){
      return loadSoloHistoryFromFirebase().catch(function(){equityHistory=loadEquityHistory();});
    }).then(function(){
      goal=loadGoal(); updateAuthIdentityUI(); initApp();
    }).catch(function(err){
      console.error("Erro ao abrir solo:",err); updateAuthIdentityUI(); initApp();
    });
    return;
  }
  setActiveScreen("ts");
}

function renderProfileList() {
  var list = $("profile-list");
  if (!list) return;
  list.innerHTML = "";
  var profiles = getProfiles();
  if (!profiles.length) {
    list.innerHTML = '<div style="text-align:center;color:var(--tx4);font-size:11px;padding:10px">Nenhum perfil ainda. Crie o primeiro!</div>';
    return;
  }
  profiles.forEach(function(name) {
    var card = document.createElement("div");
    card.style.cssText = "background:var(--bg2);border-radius:10px;padding:12px 14px;margin-bottom:8px;border:1px solid var(--bd);display:flex;justify-content:space-between;align-items:center;";
    var left = document.createElement("div");
    var avatar = document.createElement("div");
    avatar.style.cssText = "width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#1e4a80,#2563eb);display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;margin-right:10px;vertical-align:middle";
    avatar.textContent = name.charAt(0).toUpperCase();
    var nameEl = document.createElement("span");
    nameEl.style.cssText = "font-weight:700;font-size:13px;color:var(--tx);vertical-align:middle";
    var meta0 = getProfileMeta(name);
    nameEl.textContent = (meta0 && meta0.type==="group") ? (meta0.roomName + " · " + meta0.displayName) : name;
    left.style.display = "flex";
    left.style.alignItems = "center";
    left.appendChild(avatar);
    left.appendChild(nameEl);
    // Type badge
    var meta = getProfileMeta(name);
    var isGroup = meta && meta.type === "group";
    var badge = document.createElement("span");
    badge.style.cssText = "font-size:9px;padding:2px 7px;border-radius:10px;font-weight:700;letter-spacing:1px;margin-left:6px;background:"+(isGroup?"rgba(251,191,36,.15)":"rgba(96,165,250,.15)")+";color:"+(isGroup?"var(--a)":"var(--bl)");
    badge.textContent = isGroup ? "GRUPO" : "SOLO";
    nameEl.appendChild(badge);

    var btns = document.createElement("div");
    btns.style.cssText = "display:flex;gap:6px;align-items:center";

    var enterBtn = document.createElement("button");
    enterBtn.style.cssText = "padding:7px 16px;background:linear-gradient(135deg,#1e4a80,#2563eb);border:none;border-radius:7px;color:#fff;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit";
    enterBtn.textContent = "ENTRAR";
    (function(n){ enterBtn.onclick = function(){ enterProfile(n); }; })(name);

    var delBtn = document.createElement("button");
    delBtn.style.cssText = "padding:7px 10px;background:transparent;border:1px solid rgba(240,64,96,.4);border-radius:7px;color:var(--r);font-size:11px;font-weight:700;cursor:pointer;font-family:inherit";
    delBtn.textContent = "X";
    (function(n){ delBtn.onclick = function(e){ e.stopPropagation(); if(!confirm("Excluir perfil "+n+"?")) return; deleteProfile(n); renderProfileList(); }; })(name);

    btns.appendChild(enterBtn);
    btns.appendChild(delBtn);
    card.appendChild(left);
    card.appendChild(btns);
    list.appendChild(card);
  });
}

function enterProfile(name) {
  saveProfile(name);
  // Load room if group profile
  var meta = getProfileMeta(name);
  // Fallback: detect by naming convention
  if (!meta && name && name.indexOf("grupo_") === 0) {
    var _parts = name.split("_");
    if (_parts.length >= 3) {
      meta = {profileId:name, displayName:_parts.slice(2).join("_"), type:"group", roomId:_parts[1], roomName:name};
      setProfileMeta(name, meta);
    }
  }
  if (meta && meta.type === "group" && meta.roomId) {
    currentRoomId = meta.roomId;
    localStorage.setItem("hb_room_id", meta.roomId);
    joinRoom(meta.roomId).then(function(room){
      currentRoomData = room;
    }).catch(function(){
      currentRoomData = {name: meta.roomName, roomId: meta.roomId};
    });
  } else {
    currentRoomId = "";
    currentRoomData = null;
    localStorage.removeItem("hb_room_id");
  }
  // Reload state for this profile
  var st2 = loadState();
  bal = st2.bal; port = st2.port; trd = st2.trd; pending = st2.pending;
  divs = st2.divs; totalDiv = st2.totalDiv; checkedDivDate = st2.checkedDivDate;
  initialBal = st2.initialBal; firstTradeDate = st2.firstTradeDate;
  goal = loadGoal();
  equityHistory = loadEquityHistory();
  $("ps").style.display = "none";
  if (!$("ma").style.display || $("ma").style.display === "none") {
    initApp();
  } else {
    updateProfileIndicator();
    render();
  }
}

function updateProfileIndicator() {
  updateAuthIdentityUI();
}

function renderSettingsProfiles() {
  var el = $("settings-profiles");
  if (!el) return;
  var profiles = getProfiles();
  var current = getCurrentProfile();
  el.innerHTML = "";
  profiles.forEach(function(name) {
    var row = document.createElement("div");
    row.style.cssText = "display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--bd)";
    var nameEl = document.createElement("span");
    nameEl.style.cssText = "font-size:11px;color:" + (name === current ? "var(--bl)" : "var(--tx2)") + ";font-weight:" + (name === current ? "700" : "400");
    nameEl.textContent = name + (name === current ? " (ativo)" : "");
    var delBtn = document.createElement("button");
    delBtn.style.cssText = "padding:3px 8px;background:transparent;border:1px solid rgba(240,64,96,.4);border-radius:5px;color:var(--r);font-size:9px;font-weight:700;cursor:pointer;font-family:inherit";
    delBtn.textContent = "EXCLUIR";
    (function(n){
      delBtn.onclick = function(){
        if (n === current) { notif("Nao pode excluir o perfil ativo","err"); return; }
        if (!confirm("Excluir perfil " + n + "? Todos os dados serao apagados.")) return;
        deleteProfile(n);
        renderSettingsProfiles();
        notif("Perfil " + n + " excluido");
      };
    })(name);
    row.appendChild(nameEl);
    if (name !== current) row.appendChild(delBtn);
    el.appendChild(row);
  });
}

function initApp() {
  $("ts").style.display="none"; $("ma").style.display="flex";

  document.querySelectorAll(".tab").forEach(function(b) {
    b.onclick = function() {
      document.querySelectorAll(".tab").forEach(function(x){ x.classList.remove("on"); });
      document.querySelectorAll(".panel").forEach(function(x){ x.classList.remove("on"); });
      b.classList.add("on");
      $(b.dataset.t + "-panel").classList.add("on");
      $("pb").style.display = b.dataset.t === "chart" ? "flex" : "none";
      if (b.dataset.t === "chart") { setTimeout(function(){ loadTV(); }, 30); }
      if (b.dataset.t === "group") { renderGroupPanel(); }
      if (b.dataset.t === "portfolio") { setTimeout(function(){ drawEquityChart(); }, 30); }
      if (b.dataset.t === "news") {
        renderNewsTab();
        if (!newsCache.length) { newsLastFetch=0; fetchNews(); }
      }
    };
  });;

  document.querySelectorAll(".pbb").forEach(function(b) {
    b.onclick=function() {
      document.querySelectorAll(".pbb").forEach(function(x){x.classList.remove("on");}); b.classList.add("on"); per=b.dataset.p; loadTV();
    };
  });

  $("ot-mkt").onclick=function() { orderMode="market"; $("ot-mkt").classList.add("on"); $("ot-lmt").classList.remove("on"); $("lmt-wrap").style.display="none"; updateExecBtn(); };
  $("ot-lmt").onclick=function() { orderMode="limit"; $("ot-lmt").classList.add("on"); $("ot-mkt").classList.remove("on"); $("lmt-wrap").style.display="block"; var p=prices[sel]; if(p&&!$("lmt-price").value) $("lmt-price").value=p.toFixed(2); updateExecBtn(); };
  $("lmt-price").oninput=function(){ renderOrders(); };

  $("bbuy").onclick=function() { side="buy"; $("bbuy").style.cssText="background:var(--g);color:#fff;box-shadow:0 0 20px rgba(0,200,150,.35);"; $("bsel").style.cssText="background:var(--bg3);color:var(--tx3);"; updateExecBtn(); renderOrders(); };
  $("bsel").onclick = function() {
    side = "sell"; qty = 0;
    if ($("qinp")) $("qinp").value = "";
    $("bsel").style.cssText = "background:var(--r);color:#fff;box-shadow:0 0 20px rgba(240,64,96,.35);";
    $("bbuy").style.cssText = "background:var(--bg3);color:var(--tx3);";
    updateExecBtn();
    renderOrders();
    showSellableTickers();
    if ($("ticker-search")) $("ticker-search").focus();
  };
  $("qclear").onclick=function(){
    qty=0; $("qinp").value=""; $("qinp").focus(); renderOrders();
  };
  // Increment buttons (+50, +100, +500, +1000)
  document.querySelectorAll(".pr-inc").forEach(function(b){
    b.onclick=function(){
      var inc=+b.dataset.inc;
      qty=Math.max(1, qty+inc);
      $("qinp").value=qty;
      renderOrders();
    };
  });

  // Max button - use all available balance
  $("max-btn").onclick=function(){
    var p=prices[sel]||0;
    if(!p){notif("Sem cotacao para calcular","err");return;}
    if(side==="sell"){
      var pos=port[sel];
      if(!pos){notif("Sem posicao para vender","err");return;}
      qty=pos.qty;
    } else {
      var useP=(orderMode==="limit")?(parseFloat($("lmt-price").value)||p):p;
      qty=Math.max(1,Math.floor(bal/useP));
    }
    $("qinp").value=qty;
    renderOrders();
    notif("Quantidade maxima: "+qty+" cotas");
  };

  $("exec").onclick=execOrder;

  $("theme-dark").onclick = function(){ applyTheme("dark"); };
  $("theme-light").onclick = function(){ applyTheme("light"); };
  $("cfgb").onclick=function() {
    updateContextActionsUI();
    applyTheme(localStorage.getItem(LS_THEME)||"dark");
    $("tdsp").textContent=token.slice(0,8)+"..."+token.slice(-4); $("s-end").value=goal.endDate||""; $("s-tgt").value=goal.target||""; buildTapePicker(); $("sht").classList.add("on");
  };
  $("csht").onclick=function(){ $("sht").classList.remove("on"); };
  $("sht").onclick=function(e){ if(e.target===$("sht")) $("sht").classList.remove("on"); };

  $("tape-save").onclick = function() {
    var picker = document.getElementById("tape-picker");
    if (!picker) return;
    var selected = [];
    var checks = picker.querySelectorAll("input[type=checkbox]:checked");
    for (var i=0; i<checks.length; i++) selected.push(checks[i].value);
    if (!selected.length) { notif("Selecione ao menos 1 ticker","err"); return; }
    // Always pin IBOV and USDBRL at start
    var final = PINNED_TICKERS.concat(selected.filter(function(t){
      return PINNED_TICKERS.indexOf(t) === -1;
    }));
    TAPE_TICKERS = final;
    localStorage.setItem("hb_tape_v1", JSON.stringify(final));
    $("sht").classList.remove("on");
    renderTickers();
    notif("Tape: " + final.length + " tickers salvos!");
  };

  $("s-save").onclick=function() {
    var d=$("s-end").value, t=parseFloat($("s-tgt").value);
    goal={}; if(d) goal.endDate=d; if(!isNaN(t)&&t>0) goal.target=t;
    saveGoal(); $("sht").classList.remove("on"); render(); notif("Configuracoes salvas!");
  };
  $("s-clr").onclick=function() { goal={}; saveGoal(); $("s-end").value=""; $("s-tgt").value=""; render(); notif("Meta removida"); };
  $("s-rst").onclick=function() {
    // Only allow reset if no first trade yet OR show warning
    if (firstTradeDate && (!goal.endDate || new Date() < new Date(goal.endDate+"T00:00:00"))) {
      // Still show reset but warn
    }
    $("sht").classList.remove("on");
    $("reset-bal").value = initialBal;
    $("cfm").classList.add("on");
  };
  $("c-no").onclick=function() { $("cfm").classList.remove("on"); };
  $("liq-btn").onclick = function(){
    if (!isPregaoOpen()){ notif("Pregao fechado","err"); return; }
    var tks = Object.keys(port);
    if (!tks.length){ notif("Carteira vazia","err"); return; }
    tks.forEach(function(tk){
      var p=prices[tk], pos2=port[tk];
      if (!p||!pos2) return;
      var tot=p*pos2.qty; bal+=tot;
      trd.unshift({id:Date.now(),tk:tk,tp:"V",qty:pos2.qty,pr:p,tot:tot,
        tm:new Date().toLocaleTimeString("pt-BR"),note:"Liquidacao"});
      delete port[tk];
    });
    if (trd.length>200) trd=trd.slice(0,200);
    saveState(); render(); notif("Posicoes liquidadas!");
  };

  $("c-yes").onclick=function() {
    var newBal = parseFloat($("reset-bal").value);
    if (!newBal||newBal<1000) { notif("Saldo minimo: R$ 1.000,00","err"); return; }
    bal=newBal; initialBal=newBal; port={}; trd=[]; pending=[];
    divs=[]; totalDiv=0; checkedDivDate=""; equityHistory=[];
    firstTradeDate="";
    saveState(); saveEquityHistory();
    $("cfm").classList.remove("on"); render();
    notif("Simulador resetado! Saldo: "+R(newBal));
  };
  $("cfm").onclick=function(e){ if(e.target===$("cfm")) $("cfm").classList.remove("on"); };

  // After-hours order modal
  $("aho-no").onclick=function() { $("aho-modal").style.display="none"; ahoOrder=null; };
  $("aho-yes").onclick=function() {
    if (!ahoOrder) return;
    // Validate sell: must have position
    if (ahoOrder.side === "sell") {
      var pos = port[ahoOrder.tk];
      if (!pos || pos.qty <= 0) {
        notif("Você não possui " + ahoOrder.tk + " em carteira", "err");
        $("aho-modal").classList.remove("on"); ahoOrder=null;
        return;
      }
      if (ahoOrder.qty > pos.qty) {
        ahoOrder.qty = pos.qty;
        notif("Quantidade ajustada para " + pos.qty + " (máximo disponível)", "err");
      }
    }
    // Validate buy: must have balance (use last known price)
    if (ahoOrder.side === "buy" && !ahoOrder.lp) {
      var p = prices[ahoOrder.tk] || 0;
      if (p > 0 && p * ahoOrder.qty > bal) {
        notif("Saldo insuficiente para esta ordem", "err");
        $("aho-modal").classList.remove("on"); ahoOrder=null;
        return;
      }
    }
    pending.push(ahoOrder);
    saveState(); render();
    var side2=ahoOrder.side==="buy"?"COMPRA":"VENDA";
    var type2=ahoOrder.market?"a mercado":"limitada @ "+R(ahoOrder.lp);
    sfxBolt();
    notif("Agendada: "+ahoOrder.qty+" "+ahoOrder.tk+" "+side2+" "+type2);
    $("aho-modal").classList.remove("on"); ahoOrder=null;
    // Switch to orders tab to show pending
    document.querySelectorAll(".tab").forEach(function(b){b.classList.remove("on");});
    document.querySelectorAll(".panel").forEach(function(p){p.classList.remove("on");});
    var orderTab = document.querySelector(".tab[data-t='order']");
    if(orderTab) orderTab.classList.add("on");
    if($("order-panel")) $("order-panel").classList.add("on");
  };
  $("aho-modal").onclick=function(e){ if(e.target===$("aho-modal")){$("aho-modal").style.display="none";ahoOrder=null;} };
  $("logb").onclick = function() { doAuthLogout(); };
  if ($("leave-group-btn")) {
    $("leave-group-btn").onclick = function() {
      if (!confirm("Deseja sair deste grupo?")) return;
      leaveCurrentGroup().catch(function(err){ console.error(err); notif("Erro ao sair do grupo","err"); });
    };
  }
  if ($("delete-group-btn")) {
    $("delete-group-btn").onclick = function() {
      if (!confirm("Deseja EXCLUIR este grupo para todos os participantes?")) return;
      deleteCurrentGroup().catch(function(err){ console.error(err); notif("Erro ao excluir grupo","err"); });
    };
  }
  if ($("back-to-solo-btn")) {
    $("back-to-solo-btn").onclick = function() { switchToSoloProfile(); $("sht").classList.remove("on"); };
  }
  if ($("invite-btn")) {
    $("invite-btn").onclick = function() { shareRoomInvite(); };
  }
  if ($("back-to-solo-btn")) { $("back-to-solo-btn").onclick=function(){switchToSoloProfile();$("sht").classList.remove("on");}; }
  $("fs-up").onclick=function(){ applyFontScale(fontIdx+1); };
  $("fs-down").onclick=function(){ applyFontScale(fontIdx-1); };
  // switch-profile-btn removed
  $("invite-btn").onclick = function() {
    if (!token) { notif("Entre no app primeiro","err"); return; }
    var base = window.location.href.split("?")[0];
    var enc = encodeToken(token);
    var url = base + "?t=" + enc;
    var msg = "Oi! Te convido para simular investimentos na bolsa comigo no Trading GP." +
      " Acesse o link abaixo, crie seu perfil e comece a operar com cotacoes reais da B3:" +
      " " + url +
      " Nao precisa criar conta em nenhum lugar. So clicar, criar seu nome e comecar!";
    window.open("https://wa.me/?text=" + encodeURIComponent(msg), "_blank");
  };

  updateExecBtn(); updatePregaoBar(); updateAuthIdentityUI(); render(); loadTV(); startRefresh();
  hideLegacyProfileUI();
  setTimeout(function(){
    if ($("chart-panel")&&$("chart-panel").classList.contains("on")) loadTV();
    if ($("portfolio-panel")&&$("portfolio-panel").classList.contains("on")) drawEquityChart();
  }, 50);
  // Show/hide invite button based on owner status
  var invBtn = $("invite-btn");
  if (invBtn) invBtn.style.display = isOwner() ? "flex" : "none";
  initTickerSearch();
  initNewsTape();
  // If cached news exist, build tape immediately
  if (newsCache.length) { buildNewsTape(); }
  // Fetch fresh news after 2s
  setTimeout(function(){ fetchNews(); }, 2000);
  // Refresh news every 15 min
  setInterval(function(){ fetchNews(); }, 15*60*1000);
  // Tape watchdog: restart animation if it stopped
  setInterval(function(){
    if (newsTapeOneW > 0) {
      cancelAnimationFrame(newsTapeRAF);
      newsTapeLoop();
    }
  }, 8000);
}

$("auth-pass").addEventListener("keydown",function(e){ if(e.key==="Enter") doAuthLogin(); });
$("auth-pass2").addEventListener("keydown",function(e){ if(e.key==="Enter") doAuthRegister(); });

$("profile-create").onclick = function() {
  var name = $("profile-name").value.trim();
  if (!name || name.length < 2) { notif("Digite um nome (min. 2 caracteres)","err"); return; }
  enterProfile(name);
};
$("profile-name").addEventListener("keydown",function(e){ if(e.key==="Enter") $("profile-create").click(); });

// Check if arriving via invite link
var urlToken = getTokenFromUrl();
if (urlToken && !token) {
  token = urlToken;
  localStorage.setItem(LS_TOKEN, token);
  localStorage.setItem("hb_is_owner", "0"); // guest
}

if (token) {
  $("ts").style.display = "none";
  if (localStorage.getItem("hb_is_owner") === null) {
    var hasInvite = window.location.search.indexOf("t=") >= 0;
    localStorage.setItem("hb_is_owner", hasInvite ? "0" : "1");
  }
  if (getCurrentProfile()) {
    // If group profile, restore room before loading state
    var _bootProfile = getCurrentProfile();
    if (_bootProfile && _bootProfile.indexOf("grupo_") === 0) {
      var _bootParts = _bootProfile.split("_");
      var _bootMeta = getProfileMeta(_bootProfile);
      if (!_bootMeta) {
        _bootMeta = {profileId:_bootProfile, displayName:_bootParts.slice(2).join("_"), type:"group", roomId:_bootParts[1], roomName:_bootParts[1]};
        setProfileMeta(_bootProfile, _bootMeta);
      }
      currentRoomId = _bootMeta.roomId;
      localStorage.setItem("hb_room_id", currentRoomId);
      // Load room data async - don't block boot
      joinRoom(currentRoomId).then(function(room){
        currentRoomData = room;
        _bootMeta.roomName = room.name;
        setProfileMeta(_bootProfile, _bootMeta);
      }).catch(function(){
        currentRoomData = {name: _bootMeta.roomName || _bootMeta.roomId};
      });
    } else {
      currentRoomId = "";
      currentRoomData = null;
      localStorage.removeItem("hb_room_id");
    }
    var st2 = loadState();
    bal=st2.bal; port=st2.port; trd=st2.trd; pending=st2.pending;
    divs=st2.divs; totalDiv=st2.totalDiv; checkedDivDate=st2.checkedDivDate;
    initialBal=st2.initialBal; firstTradeDate=st2.firstTradeDate;
    goal=loadGoal(); equityHistory=loadEquityHistory();
    initApp();
  } else {
    showProfileScreen();
  }
}


$("auth-pass").addEventListener("keydown",function(e){ if(e.key==="Enter") doAuthLogin(); });
$("auth-pass2").addEventListener("keydown",function(e){ if(e.key==="Enter") doAuthRegister(); });

$("profile-create").onclick = function() {
  var name = $("profile-name").value.trim();
  if (!name || name.length < 2) { notif("Digite um nome (min. 2 caracteres)","err"); return; }
  enterProfile(name);
};
$("profile-name").addEventListener("keydown",function(e){ if(e.key==="Enter") $("profile-create").click(); });

// Check if arriving via invite link
var urlToken = getTokenFromUrl();
if (urlToken && !token) {
  token = urlToken;
  localStorage.setItem(LS_TOKEN, token);
  localStorage.setItem("hb_is_owner", "0"); // guest
}

function ensureUserBaseData(user) {
  if (!user || !fbDb) return Promise.reject(new Error("Usuário/Firebase indisponível"));
  var uid=user.uid, displayName=user.displayName||"Jogador", email=user.email||"";
  return fbDb.ref("users/"+uid).once("value").then(function(snap) {
    if (!snap.exists()) return fbDb.ref("users/"+uid).set({uid:uid,displayName:displayName,email:email,createdAt:Date.now()});
  }).then(function() {
    return fbDb.ref("soloPortfolios/"+uid).once("value");
  }).then(function(snap) {
    if (!snap.exists()) return fbDb.ref("soloPortfolios/"+uid).set({cash:100000,positions:{},trades:[],pendingOrders:[],dividends:{},totalDiv:0,initialBal:100000,firstTradeDate:"",updatedAt:Date.now()});
  }).then(function() {
    ensureSoloProfile();
  });
}

function setActiveScreen(screen) {
  ["ts","ps","gs","ma"].forEach(function(id) {
    var el=$(id); if(!el)return;
    el.style.display = (id===screen) ? "flex" : "none";
  });
}

function showAuthScreen() {
  setActiveScreen("ts");
  showAuthTab("login");
}

function enterAppAfterAuth() {
  setActiveScreen("ma");
  var soloId=ensureSoloProfile();
  if(!getCurrentProfile()) localStorage.setItem(LS_PROFILE, soloId);
  updateAuthIdentityUI();

  // Check for room param (invite link)
  var _roomParam=new URLSearchParams(window.location.search).get("room");
  if(_roomParam){
    loadSoloFromFirebase().then(function(){
      return joinRoom(_roomParam.toUpperCase()).then(function(roomData){
        showGroupJoinScreen(roomData);
        try{var _u=new URL(window.location.href);_u.searchParams.delete("room");window.history.replaceState({},"",_u.pathname+(_u.search||""));}catch(e){}
      }).catch(function(){notif("Grupo não encontrado","err");initApp();});
    });
    return;
  }

  var _savedRoomId=currentUser?localStorage.getItem("hb_active_room_"+currentUser.uid):null;

  if(_savedRoomId){
    // User had a group active — load group context directly
    currentRoomId=_savedRoomId;
    joinRoom(_savedRoomId).then(function(room){
      currentRoomData=room;
      goal={
        endDate:(room&&room.endDate)||"",
        target:Number((room&&room.targetPct)||0)
      };
      return loadGroupPortfolioFromFirebase(_savedRoomId, getCurrentProfile());
    }).then(function(){
      return loadGroupHistoryFromFirebase(_savedRoomId, getCurrentProfile())
        .catch(function(){equityHistory=[];});
    }).then(function(){
      initApp(); updateContextActionsUI();
    }).catch(function(err){
      console.error("Erro ao restaurar grupo:",err);
      // Fallback: clear group context, load solo
      currentRoomId=""; currentRoomData=null;
      localStorage.removeItem("hb_active_room_"+currentUser.uid);
      loadSoloFromFirebase().then(function(){
        return loadSoloHistoryFromFirebase().catch(function(){equityHistory=loadEquityHistory();});
      }).then(function(){
        goal=loadGoal(); initApp(); updateContextActionsUI();
      }).catch(function(){ initApp(); });
    });
    return;
  }

  // Solo context — load solo data
  loadSoloFromFirebase().then(function(){
    return loadSoloHistoryFromFirebase().catch(function(){equityHistory=loadEquityHistory();});
  }).then(function(){
    goal=loadGoal();
    initApp(); updateContextActionsUI();
  }).catch(function(err){
    console.error("Erro ao carregar solo:",err);
    notif("Erro ao carregar carteira","err");
    initApp();
  });
}

if (fbAuth) {
  fbAuth.onAuthStateChanged(function(user) {
    currentUser = user || null;
    if (!user) { showAuthScreen(); return; }
    ensureUserBaseData(user).then(function() {
      enterAppAfterAuth();
    }).catch(function(err) {
      console.error("Erro ao preparar conta:", err);
      showAuthScreen();
      if ($("auth-err")) { $("auth-err").textContent="Erro ao carregar sua conta."; $("auth-err").style.display="block"; }
    });
  });
}




/* ══ AVATAR PANEL ══ */
var _avRain;
function _startAvRain(){
  var cv=document.getElementById('av-rain'); if(!cv)return;
  var ctx=cv.getContext('2d');
  cv.width=cv.offsetWidth; cv.height=cv.offsetHeight;
  var W=cv.width,H=cv.height,chars='01アイウエオ∑∆√',drops=[];
  for(var i=0;i<Math.floor(W/14);i++) drops[i]=Math.random()*-20;
  _avRain=setInterval(function(){
    ctx.fillStyle='rgba(2,6,2,.18)'; ctx.fillRect(0,0,W,H);
    ctx.font='12px monospace';
    drops.forEach(function(d,i){
      ctx.fillStyle='rgba(0,255,90,'+(0.7*(1-d*14/H))+')';
      ctx.fillText(chars[Math.floor(Math.random()*chars.length)],i*14,d*14);
      if(d*14>H&&Math.random()>.96) drops[i]=0; drops[i]+=.4;
    });
  },50);
}
function _stopAvRain(){ clearInterval(_avRain); }

/* ══ HOODIE GHOST ══ */
var _hoodieT=null, _hoodieG=null;

function _hoodieStop(){
  clearTimeout(_hoodieT); clearTimeout(_hoodieG);
  var h=document.getElementById('av-hoodie');
  if(h){h.style.opacity='0';h.style.transform='';}
}

function _hoodieGlitch(el,cb){
  var steps=3+Math.floor(Math.random()*4),i=0;
  function tick(){
    if(i>=steps){el.style.transform='';el.style.filter='drop-shadow(0 0 18px rgba(0,255,90,.85))';if(cb)cb();return;}
    var dx=(Math.random()-.5)*24,dy=(Math.random()-.5)*10;
    el.style.transform='translate('+dx+'px,'+dy+'px) scaleX('+(i%2===0?.88:1.08)+')';
    el.style.filter=i%2===0
      ?'drop-shadow(-3px 0 rgba(255,0,80,.9)) drop-shadow(3px 0 rgba(0,255,90,.7))'
      :'drop-shadow(0 0 22px rgba(0,255,90,1))';
    i++;
    _hoodieG=setTimeout(tick,40+Math.random()*55);
  }
  tick();
}

function _hoodieAnimate(){
  if(!document.body.classList.contains('matrix'))return;
  var panel=document.getElementById('avatar-panel');
  if(!panel||!panel.classList.contains('on'))return;
  var h=document.getElementById('av-hoodie');
  var hero=h&&h.closest('.av-hero');
  if(!h||!hero)return;
  var W=hero.offsetWidth,H=hero.offsetHeight,hw=72,hh=94;
  var x=8+Math.random()*(W-hw-16);
  var y=4+Math.random()*(H-hh-8);
  h.style.left=x+'px'; h.style.top=y+'px'; h.style.transform='';
  var op=(.45+Math.random()*.45).toFixed(2);
  h.style.transition='opacity .14s ease'; h.style.opacity=op;
  var stay=500+Math.random()*1800;
  if(Math.random()>.45){
    _hoodieG=setTimeout(function(){
      _hoodieGlitch(h,function(){
        if(Math.random()>.5){
          h.style.transition='opacity .06s ease'; h.style.opacity='0';
          _hoodieT=setTimeout(function(){
            var x2=8+Math.random()*(W-hw-16), y2=4+Math.random()*(H-hh-8);
            h.style.left=x2+'px'; h.style.top=y2+'px';
            h.style.transition='opacity .1s ease';
            h.style.opacity=(.5+Math.random()*.4).toFixed(2);
          },90);
        }
      });
    },stay*(.2+Math.random()*.4));
  }
  _hoodieT=setTimeout(function(){
    clearTimeout(_hoodieG);
    h.style.transition='opacity .08s ease'; h.style.opacity='0';
    _hoodieT=setTimeout(_hoodieAnimate,150+Math.random()*1100);
  },stay);
}

/* ══ ABRIR / FECHAR PAINEL ══ */
function openAvatarPanel(){
  document.getElementById('avatar-panel').classList.add('on');
  document.body.style.overflow='hidden';
  _startAvRain&&_startAvRain();
  if(document.body.classList.contains('matrix')){
    setTimeout(_hoodieAnimate,400);
  }
  _updateAvatar&&_updateAvatar();
}

function closeAvatarPanel(){
  document.getElementById('avatar-panel').classList.remove('on');
  document.body.style.overflow='';
  _stopAvRain&&_stopAvRain();
  _hoodieStop();
}

function _calcLevel(xpTotal){
  var lv=1,needed=200,rem=xpTotal;
  while(rem>=needed){rem-=needed;lv++;needed=lv*200;}
  return{level:lv,curr:Math.round(rem),needed:needed,total:Math.round(xpTotal)};
}

function _updateAvatar(){
  var trades=typeof trd!=='undefined'?trd:[];
  var saldo=typeof bal!=='undefined'?bal:100000;
  var init=typeof initialBal!=='undefined'?initialBal:100000;
  var firstD=typeof firstTradeDate!=='undefined'?firstTradeDate:'';
  var portObj=typeof port!=='undefined'?port:{};

  var numTrades=trades.length;
  var wins=trades.filter(function(t){return t.pnl>0;}).length;
  var winRate=numTrades>0?Math.round(wins/numTrades*100):0;
  var rentPct=(saldo-init)/init*100;
  var dias=firstD?Math.max(1,Math.floor((Date.now()-new Date(firstD).getTime())/86400000)):0;
  var temPosicao=Object.keys(portObj).length>0;

  var xpTotal=numTrades*100+wins*50+Math.max(0,rentPct)*5;
  var lv=_calcLevel(xpTotal);
  var pct=Math.round(lv.curr/lv.needed*100);

  document.getElementById('av-level').textContent=lv.level;
  document.getElementById('av-lvl-badge').textContent=lv.level;
  document.getElementById('av-xp-text').textContent=lv.curr.toLocaleString('pt-BR')+' / '+lv.needed.toLocaleString('pt-BR');
  document.getElementById('av-xp-fill').style.width=pct+'%';
  document.getElementById('av-xp-pct').textContent=pct+'% para o próximo nível';

  // Codename + avatar normal
  var prof=typeof getCurrentProfile==='function'?getCurrentProfile():null;
  var displayName='TRADER';
  if(prof){
    var pm=typeof getProfileMeta==='function'?getProfileMeta(prof):null;
    if(pm&&pm.displayName) displayName=pm.displayName.toUpperCase();
    else if(prof) displayName=prof.toUpperCase();
  }
  var cdEl=document.getElementById('av-codename');
  if(cdEl) cdEl.textContent=displayName;
  // Avatar normal (dark/light): inicial + nome
  var circleEl=document.getElementById('av-normal-circle');
  var nameEl=document.getElementById('av-normal-name');
  if(circleEl) circleEl.textContent=displayName.charAt(0);
  if(nameEl) nameEl.textContent=displayName;

  var ranks=[
    {min:1, icon:'🏅',name:'BRONZE I',  stars:'★',    sub:'Iniciante'},
    {min:5, icon:'🏅',name:'BRONZE II', stars:'★★',   sub:'Aprendiz'},
    {min:10,icon:'🥈',name:'PRATA I',   stars:'★★',   sub:'Operador'},
    {min:15,icon:'🥈',name:'PRATA II',  stars:'★★★',  sub:'Especulador'},
    {min:20,icon:'🥇',name:'OURO I',    stars:'★★★',  sub:'Top 12%'},
    {min:28,icon:'🥇',name:'OURO II',   stars:'★★★★', sub:'Top 5%'},
    {min:38,icon:'💎',name:'PLATINA',   stars:'★★★★★',sub:'Elite'},
    {min:50,icon:'👑',name:'DIAMANTE',  stars:'💎',    sub:'Lendário'},
  ];
  var rk=ranks[0];
  ranks.forEach(function(r){if(lv.level>=r.min)rk=r;});
  document.getElementById('av-rank-icon').textContent=rk.icon;
  document.getElementById('av-rank-name').textContent=rk.name;
  document.getElementById('av-rank-stars').textContent=rk.stars;
  document.getElementById('av-rank-sub').textContent=rk.sub;

  document.getElementById('av-trades').textContent=numTrades;
  var wrel=document.getElementById('av-winrate');
  wrel.textContent=winRate+'%'; wrel.className='av-stat-val '+(winRate>=50?'g':'r');
  var rrel=document.getElementById('av-rentab');
  rrel.textContent=(rentPct>=0?'+':'')+rentPct.toFixed(2)+'%'; rrel.className='av-stat-val '+(rentPct>=0?'g':'r');
  document.getElementById('av-days').textContent=dias;

  var m1done=numTrades>=3;
  var m1chk=document.getElementById('m1-chk');
  m1chk.textContent=m1done?'✓':(numTrades>0?'◐':'○');
  m1chk.className='mission-chk'+(m1done?' done':'');
  document.getElementById('m1-prog').textContent=Math.min(numTrades,3)+'/3';
  document.getElementById('m1-prog').style.color=m1done?'var(--g)':'var(--tx4)';
  var m3chk=document.getElementById('m3-chk');
  m3chk.textContent=temPosicao?'✓':'○';
  m3chk.className='mission-chk'+(temPosicao?' done':'');
  document.getElementById('m3-prog').textContent=temPosicao?'✓':'—';

  var cqs=document.querySelectorAll('#av-cq-grid .cq');
  var flags=[numTrades>=1,numTrades>=5,rentPct>0,Object.keys(portObj).length>=3,dias>=7,false];
  var unlocked=0;
  flags.forEach(function(f,i){cqs[i].className='cq '+(f?'unlocked':'locked');if(f)unlocked++;});
  document.getElementById('av-cq-count').textContent=unlocked+' / 6';

  var now=new Date();
  var hms=('0'+now.getHours()).slice(-2)+':'+('0'+now.getMinutes()).slice(-2)+':'+('0'+now.getSeconds()).slice(-2);
  document.getElementById('av-log').innerHTML=
    '<div class="ll">['+hms+'] PERFIL · NV '+lv.level+' · '+xpTotal.toFixed(0)+' XP</div>'+
    '<div class="ll">[RANK] '+rk.name+' · WIN '+winRate+'%</div>'+
    '> SISTEMA ESTÁVEL <span class="log-cur"></span>';
}
