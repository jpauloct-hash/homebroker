# Trading GP - Modular v1

Primeira modularização segura do arquivo original.

Arquivos:
- `index.html`: estrutura HTML e imports externos do Firebase.
- `css/styles.css`: todo o CSS extraído do bloco `<style>`.
- `js/app.js`: todo o JavaScript interno extraído do bloco final `<script>`.

Objetivo desta versão: reduzir o tamanho do `index.html` sem alterar a lógica do app.

Próximo passo recomendado: dividir `js/app.js` em módulos funcionais: config/firebase, state, quotes, orders, portfolio, groups, charts, news e ui.
